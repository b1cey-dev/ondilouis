'use client'

import { useState } from 'react';
import Link from 'next/link';
import Image from 'next/image';

export default function Home() {
  const [expanded, setExpanded] = useState(true);

  const toggleExpanded = () => {
    setExpanded(!expanded);
  };

  return (
    <div className="w-full bg-gray-100 min-h-screen flex flex-col">
      {/* Navbar */}
      <nav className="bg-white border-b border-gray-200 sticky top-0 shadow-sm">
        <div className="max-w-7xl mx-auto px-4 h-14 flex items-center justify-between">
          <div className="flex items-center">
            <Link href="/" className="text-slate-800 font-bold text-xl flex items-center">
              <span className="text-[#E60012]">Blox</span>
              <span>Bazaar</span>
            </Link>
          </div>
          
          <div className="hidden md:flex items-center space-x-1">
            <Link href="/marketplace" className="px-3 py-2 text-slate-600 rounded hover:bg-slate-50 flex items-center">
              <svg xmlns="http://www.w3.org/2000/svg" className="h-5 w-5 mr-1" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2">
                <path d="M3 3h18v18H3zM12 8v8m-4-4h8"></path>
              </svg>
              <span>Marketplace</span>
            </Link>

            <Link href="/forums" className="px-3 py-2 text-slate-600 rounded hover:bg-slate-50 flex items-center">
              <svg xmlns="http://www.w3.org/2000/svg" className="h-5 w-5 mr-1" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2">
                <path d="M21 15a2 2 0 0 1-2 2H7l-4 4V5a2 2 0 0 1 2-2h14a2 2 0 0 1 2 2z"></path>
              </svg>
              <span>Forums</span>
            </Link>
            
            <Link href="/learn" className="px-3 py-2 text-slate-600 rounded hover:bg-slate-50 flex items-center">
              <svg xmlns="http://www.w3.org/2000/svg" className="h-5 w-5 mr-1" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2">
                <path d="M2 3h6a4 4 0 0 1 4 4v14a3 3 0 0 0-3-3H2z"></path>
                <path d="M22 3h-6a4 4 0 0 0-4 4v14a3 3 0 0 1 3-3h7z"></path>
              </svg>
              <span>Learn</span>
            </Link>

            <div className="px-3 py-2 text-slate-600 rounded hover:bg-slate-50 flex items-center cursor-pointer group relative">
              <svg xmlns="http://www.w3.org/2000/svg" className="h-5 w-5 mr-1" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2">
                <circle cx="12" cy="12" r="3"></circle>
                <path d="M19.4 15a1.65 1.65 0 0 0 .33 1.82l.06.06a2 2 0 0 1 0 2.83 2 2 0 0 1-2.83 0l-.06-.06a1.65 1.65 0 0 0-1.82-.33 1.65 1.65 0 0 0-1 1.51V21a2 2 0 0 1-2 2 2 2 0 0 1-2-2v-.09A1.65 1.65 0 0 0 9 19.4a1.65 1.65 0 0 0-1.82.33l-.06.06a2 2 0 0 1-2.83 0 2 2 0 0 1 0-2.83l.06-.06a1.65 1.65 0 0 0 .33-1.82 1.65 1.65 0 0 0-1.51-1H3a2 2 0 0 1-2-2 2 2 0 0 1 2-2h.09A1.65 1.65 0 0 0 4.6 9a1.65 1.65 0 0 0-.33-1.82l-.06-.06a2 2 0 0 1 0-2.83 2 2 0 0 1 2.83 0l.06.06a1.65 1.65 0 0 0 1.82.33H9a1.65 1.65 0 0 0 1-1.51V3a2 2 0 0 1 2-2 2 2 0 0 1 2 2v.09a1.65 1.65 0 0 0 1 1.51 1.65 1.65 0 0 0 1.82-.33l.06-.06a2 2 0 0 1 2.83 0 2 2 0 0 1 0 2.83l-.06.06a1.65 1.65 0 0 0-.33 1.82V9a1.65 1.65 0 0 0 1.51 1H21a2 2 0 0 1 2 2 2 2 0 0 1-2 2h-.09a1.65 1.65 0 0 0-1.51 1z"></path>
              </svg>
              <span>Resources</span>
              <svg xmlns="http://www.w3.org/2000/svg" className="h-4 w-4 ml-1" viewBox="0 0 20 20" fill="currentColor">
                <path fillRule="evenodd" d="M5.293 7.293a1 1 0 011.414 0L10 10.586l3.293-3.293a1 1 0 111.414 1.414l-4 4a1 1 0 01-1.414 0l-4-4a1 1 0 010-1.414z" clipRule="evenodd" />
              </svg>
            </div>
          </div>
          
          <div className="flex items-center space-x-3">
            <Link href="/go-pro" className="bg-[#E60012] text-white px-4 sm:px-6 py-2 rounded text-sm font-medium flex items-center hover:bg-[#CC0000] transition">
              <svg xmlns="http://www.w3.org/2000/svg" className="h-5 w-5 mr-1" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2">
                <path d="M12 2L2 7l10 5 10-5-10-5zM2 17l10 5 10-5M2 12l10 5 10-5"></path>
              </svg>
              <span>Go Pro</span>
            </Link>
            
            <div className="flex items-center space-x-2">
              <Link href="/account" className="w-8 h-8 rounded-full bg-slate-800 text-white flex items-center justify-center font-bold hover:bg-slate-700 transition">
                B
              </Link>
            </div>
          </div>
        </div>
      </nav>

      {/* Hero Banner */}
      <div className="bg-gradient-to-r from-slate-800 to-slate-900 py-8 sm:py-12 md:py-16">
        <div className="max-w-6xl mx-auto px-4 sm:px-6">
          <div className="text-white max-w-2xl">
            <h1 className="text-3xl sm:text-4xl md:text-5xl font-bold mb-3 sm:mb-4">Welcome to BloxBazaar</h1>
            <p className="text-lg sm:text-xl text-slate-300 mb-4 sm:mb-6">The premier marketplace for Roblox development and resources</p>
            <div className="flex flex-col sm:flex-row gap-3 sm:gap-4">
              <Link href="/forums" className="bg-white text-slate-800 px-4 sm:px-6 py-2 sm:py-3 rounded-lg font-medium hover:bg-slate-100 transition duration-200 text-center text-sm sm:text-base">
                Browse Forums
              </Link>
              <Link href="/go-pro" className="bg-[#E60012] text-white px-4 sm:px-6 py-2 sm:py-3 rounded-lg font-medium hover:bg-[#CC0000] transition duration-200 text-center text-sm sm:text-base">
                Go Pro
              </Link>
            </div>
          </div>
        </div>
      </div>

      <main className="flex-grow py-4 sm:py-6">
        <div className="max-w-6xl mx-auto px-4 sm:px-6">
          {/* Forums Header */}
          <div className="flex items-center mb-2 sm:mb-3">
            <h1 className="text-lg sm:text-xl text-slate-800 font-medium flex items-center">
              <span>Forums</span>
              <button 
                onClick={toggleExpanded}
                className="ml-2 text-gray-500"
              >
                <svg 
                  xmlns="http://www.w3.org/2000/svg" 
                  className={`h-4 w-4 sm:h-5 sm:w-5 transition-transform ${expanded ? 'rotate-180' : ''}`} 
                  viewBox="0 0 24 24" 
                  fill="none" 
                  stroke="currentColor" 
                  strokeWidth="2"
                >
                  <polyline points="6 9 12 15 18 9"></polyline>
                </svg>
              </button>
            </h1>
          </div>

          {/* Divider Line */}
          <div className="h-1 bg-slate-800 rounded mb-4 sm:mb-6"></div>

          {expanded && (
            <div className="space-y-3 sm:space-y-4">
              {/* Discussions Category */}
              <div className="bg-white rounded-lg shadow overflow-hidden mb-4 sm:mb-6">
                <div className="flex items-center p-3 sm:p-4 border-b border-gray-100">
                  <svg xmlns="http://www.w3.org/2000/svg" className="h-6 w-6 sm:h-7 sm:w-7 text-slate-600" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2">
                    <path d="M21 15a2 2 0 0 1-2 2H7l-4 4V5a2 2 0 0 1 2-2h14a2 2 0 0 1 2 2z"></path>
                  </svg>
                  <h2 className="text-lg sm:text-xl font-medium ml-2 sm:ml-3 text-slate-800">Discussions</h2>
                </div>

                <div className="space-y-2 p-3 sm:p-4">
                  <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-3 sm:gap-4">
                    <Link href="/forums/introductions" className="flex items-center space-x-2 p-2 rounded hover:bg-slate-50">
                      <svg xmlns="http://www.w3.org/2000/svg" className="h-5 w-5 text-slate-600" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2">
                        <path d="M12 2a3 3 0 0 0-3 3v4a3 3 0 0 0 6 0V5a3 3 0 0 0-3-3z"></path>
                        <path d="M19 10v1a7 7 0 0 1-14 0v-1"></path>
                        <line x1="12" y1="19" x2="12" y2="23"></line>
                        <line x1="8" y1="23" x2="16" y2="23"></line>
                      </svg>
                      <span className="text-slate-700">Introductions</span>
                    </Link>
                    
                    <Link href="/forums/game-showcase" className="flex items-center space-x-2 p-2 rounded hover:bg-slate-50">
                      <svg xmlns="http://www.w3.org/2000/svg" className="h-5 w-5 text-slate-600" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2">
                        <rect x="2" y="3" width="20" height="14" rx="2" ry="2"></rect>
                        <line x1="8" y1="21" x2="16" y2="21"></line>
                        <line x1="12" y1="17" x2="12" y2="21"></line>
                      </svg>
                      <span className="text-slate-700">Game Showcase</span>
                    </Link>
                    
                    <Link href="/forums/community-games" className="flex items-center space-x-2 p-2 rounded hover:bg-slate-50">
                      <svg xmlns="http://www.w3.org/2000/svg" className="h-5 w-5 text-slate-600" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2">
                        <path d="M17 3a2.85 2.85 0 1 1 0 5.7"></path>
                        <path d="M10 13a2.85 2.85 0 1 1 0 5.7"></path>
                        <line x1="10" y1="9" x2="17" y2="3"></line>
                        <line x1="10" y1="13" x2="17" y2="17"></line>
                      </svg>
                      <span className="text-slate-700">Community Games</span>
                    </Link>
                  </div>
                </div>
              </div>

              {/* Development Category */}
              <div className="bg-white rounded-lg shadow overflow-hidden mb-4 sm:mb-6">
                <div className="flex items-center p-3 sm:p-4 border-b border-gray-100">
                  <svg xmlns="http://www.w3.org/2000/svg" className="h-6 w-6 sm:h-7 sm:w-7 text-slate-600" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2">
                    <polyline points="16 18 22 12 16 6"></polyline>
                    <polyline points="8 6 2 12 8 18"></polyline>
                  </svg>
                  <h2 className="text-lg sm:text-xl font-medium ml-2 sm:ml-3 text-slate-800">Development</h2>
                </div>

                <div className="space-y-2 p-3 sm:p-4">
                  <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-3 sm:gap-4">
                    <Link href="/forums/scripting" className="flex items-center space-x-2 p-2 rounded hover:bg-slate-50">
                      <svg xmlns="http://www.w3.org/2000/svg" className="h-5 w-5 text-slate-600" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2">
                        <path d="M14 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V8z"></path>
                        <polyline points="14 2 14 8 20 8"></polyline>
                        <line x1="16" y1="13" x2="8" y2="13"></line>
                        <line x1="16" y1="17" x2="8" y2="17"></line>
                        <polyline points="10 9 9 9 8 9"></polyline>
                      </svg>
                      <span className="text-slate-700">Scripting</span>
                    </Link>
                    
                    <Link href="/forums/building" className="flex items-center space-x-2 p-2 rounded hover:bg-slate-50">
                      <svg xmlns="http://www.w3.org/2000/svg" className="h-5 w-5 text-slate-600" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2">
                        <line x1="4" y1="9" x2="20" y2="9"></line>
                        <line x1="4" y1="15" x2="20" y2="15"></line>
                        <line x1="10" y1="3" x2="8" y2="21"></line>
                        <line x1="16" y1="3" x2="14" y2="21"></line>
                      </svg>
                      <span className="text-slate-700">Building</span>
                    </Link>
                    
                    <Link href="/forums/ui-design" className="flex items-center space-x-2 p-2 rounded hover:bg-slate-50">
                      <svg xmlns="http://www.w3.org/2000/svg" className="h-5 w-5 text-slate-600" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2">
                        <rect x="2" y="3" width="20" height="14" rx="2" ry="2"></rect>
                        <line x1="8" y1="21" x2="16" y2="21"></line>
                        <line x1="12" y1="17" x2="12" y2="21"></line>
                      </svg>
                      <span className="text-slate-700">UI Design</span>
                    </Link>
                    
                    <Link href="/forums/animations" className="flex items-center space-x-2 p-2 rounded hover:bg-slate-50">
                      <svg xmlns="http://www.w3.org/2000/svg" className="h-5 w-5 text-slate-600" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2">
                        <rect x="2" y="3" width="20" height="14" rx="2" ry="2"></rect>
                        <line x1="8" y1="21" x2="16" y2="21"></line>
                        <line x1="12" y1="17" x2="12" y2="21"></line>
                      </svg>
                      <span className="text-slate-700">Animations</span>
                    </Link>
                    
                    <Link href="/forums/plugins" className="flex items-center space-x-2 p-2 rounded hover:bg-slate-50">
                      <svg xmlns="http://www.w3.org/2000/svg" className="h-5 w-5 text-slate-600" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2">
                        <circle cx="12" cy="12" r="10"></circle>
                        <line x1="2" y1="12" x2="22" y2="12"></line>
                        <path d="M12 2a15.3 15.3 0 0 1 4 10 15.3 15.3 0 0 1-4 10 15.3 15.3 0 0 1-4-10 15.3 15.3 0 0 1 4-10z"></path>
                      </svg>
                      <span className="text-slate-700">Plugins</span>
                    </Link>
                    
                    <Link href="/forums/other-development" className="flex items-center space-x-2 p-2 rounded hover:bg-slate-50">
                      <svg xmlns="http://www.w3.org/2000/svg" className="h-5 w-5 text-slate-600" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2">
                        <circle cx="12" cy="12" r="10"></circle>
                        <line x1="12" y1="8" x2="12" y2="16"></line>
                        <line x1="8" y1="12" x2="16" y2="12"></line>
                      </svg>
                      <span className="text-slate-700">Other Development</span>
                    </Link>
                  </div>
                </div>
              </div>

              {/* Resources Category */}
              <div className="bg-white rounded-lg shadow overflow-hidden mb-4 sm:mb-6">
                <div className="flex items-center p-3 sm:p-4 border-b border-gray-100">
                  <svg xmlns="http://www.w3.org/2000/svg" className="h-6 w-6 sm:h-7 sm:w-7 text-slate-600" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2">
                    <rect x="3" y="3" width="18" height="18" rx="2" ry="2"></rect>
                    <line x1="3" y1="9" x2="21" y2="9"></line>
                    <line x1="9" y1="21" x2="9" y2="9"></line>
                  </svg>
                  <h2 className="text-lg sm:text-xl font-medium ml-2 sm:ml-3 text-slate-800">Resources</h2>
                </div>

                <div className="space-y-2 p-3 sm:p-4">
                  <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-3 sm:gap-4">
                    <Link href="/forums/models" className="flex items-center space-x-2 p-2 rounded hover:bg-slate-50">
                      <svg xmlns="http://www.w3.org/2000/svg" className="h-5 w-5 text-slate-600" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2">
                        <line x1="8" y1="6" x2="21" y2="6"></line>
                        <line x1="8" y1="12" x2="21" y2="12"></line>
                        <line x1="8" y1="18" x2="21" y2="18"></line>
                        <line x1="3" y1="6" x2="3.01" y2="6"></line>
                        <line x1="3" y1="12" x2="3.01" y2="12"></line>
                        <line x1="3" y1="18" x2="3.01" y2="18"></line>
                      </svg>
                      <span className="text-slate-700">Models</span>
                    </Link>
                    
                    <Link href="/forums/scripts" className="flex items-center space-x-2 p-2 rounded hover:bg-slate-50">
                      <svg xmlns="http://www.w3.org/2000/svg" className="h-5 w-5 text-slate-600" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2">
                        <rect x="2" y="2" width="20" height="20" rx="2.18" ry="2.18"></rect>
                        <line x1="10" y1="8" x2="14" y2="12"></line>
                        <line x1="14" y1="8" x2="10" y2="12"></line>
                      </svg>
                      <span className="text-slate-700">Scripts</span>
                    </Link>
                    
                    <Link href="/forums/tutorials" className="flex items-center space-x-2 p-2 rounded hover:bg-slate-50">
                      <svg xmlns="http://www.w3.org/2000/svg" className="h-5 w-5 text-slate-600" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2">
                        <path d="M21 11.5a8.38 8.38 0 0 1-.9 3.8 8.5 8.5 0 0 1-7.6 4.7 8.38 8.38 0 0 1-3.8-.9L3 21l1.9-5.7a8.38 8.38 0 0 1-.9-3.8 8.5 8.5 0 0 1 4.7-7.6 8.38 8.38 0 0 1 3.8-.9h.5a8.48 8.48 0 0 1 8 8v.5z"></path>
                      </svg>
                      <span className="text-slate-700">Tutorials</span>
                    </Link>
                    
                    <Link href="/forums/other-resources" className="flex items-center space-x-2 p-2 rounded hover:bg-slate-50">
                      <svg xmlns="http://www.w3.org/2000/svg" className="h-5 w-5 text-slate-600" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2">
                        <circle cx="12" cy="12" r="10"></circle>
                        <line x1="12" y1="8" x2="12" y2="16"></line>
                        <line x1="8" y1="12" x2="16" y2="12"></line>
                      </svg>
                      <span className="text-slate-700">Other Resources</span>
                    </Link>
                  </div>
                </div>
              </div>

              {/* Marketplace Category */}
              <div className="bg-white rounded-lg shadow overflow-hidden mb-4 sm:mb-6">
                <div className="flex items-center p-3 sm:p-4 border-b border-gray-100">
                  <svg xmlns="http://www.w3.org/2000/svg" className="h-6 w-6 sm:h-7 sm:w-7 text-slate-600" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2">
                    <circle cx="9" cy="21" r="1"></circle>
                    <circle cx="20" cy="21" r="1"></circle>
                    <path d="M1 1h4l2.68 13.39a2 2 0 0 0 2 1.61h9.72a2 2 0 0 0 2-1.61L23 6H6"></path>
                  </svg>
                  <h2 className="text-lg sm:text-xl font-medium ml-2 sm:ml-3 text-slate-800">Marketplace</h2>
                </div>

                <div className="space-y-2 p-3 sm:p-4">
                  <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-3 sm:gap-4">
                    <Link href="/forums/buying" className="flex items-center space-x-2 p-2 rounded hover:bg-slate-50">
                      <svg xmlns="http://www.w3.org/2000/svg" className="h-5 w-5 text-slate-600" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2">
                        <circle cx="12" cy="12" r="10"></circle>
                        <line x1="12" y1="8" x2="12" y2="16"></line>
                        <line x1="8" y1="12" x2="16" y2="12"></line>
                      </svg>
                      <span className="text-slate-700">Buying</span>
                    </Link>
                    
                    <Link href="/forums/selling" className="flex items-center space-x-2 p-2 rounded hover:bg-slate-50">
                      <svg xmlns="http://www.w3.org/2000/svg" className="h-5 w-5 text-slate-600" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2">
                        <line x1="12" y1="1" x2="12" y2="23"></line>
                        <path d="M17 5H9.5a3.5 3.5 0 0 0 0 7h5a3.5 3.5 0 0 1 0 7H6"></path>
                      </svg>
                      <span className="text-slate-700">Selling</span>
                    </Link>
                    
                    <Link href="/forums/feedback-assistance" className="flex items-center space-x-2 p-2 rounded hover:bg-slate-50">
                      <svg xmlns="http://www.w3.org/2000/svg" className="h-5 w-5 text-slate-600" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2">
                        <path d="M21 15a2 2 0 0 1-2 2H7l-4 4V5a2 2 0 0 1 2-2h14a2 2 0 0 1 2 2z"></path>
                      </svg>
                      <span className="text-slate-700">Feedback & Assistance</span>
                    </Link>
                  </div>
                </div>
              </div>
            </div>
          )}

          {/* Latest Topics List */}
          <div className="bg-white rounded-lg shadow overflow-hidden mt-4 sm:mt-6">
            <div className="flex items-center justify-between p-3 sm:p-4 bg-slate-50 border-b border-gray-200">
              <h2 className="text-base sm:text-lg font-semibold text-slate-800">Latest Topics</h2>
            </div>
            
            <div className="divide-y divide-gray-100">
              {/* Topics will be dynamically populated here */}
            </div>
          </div>
        </div>
      </main>
    </div>
  );
}