'use client'

import { useState, useEffect } from 'react';
import Link from 'next/link';
import Image from 'next/image';

// Types for our data
interface User {
  id: number;
  name: string;
  email: string;
  role: string;
  joined: string;
  status: 'active' | 'suspended' | 'pending';
}

interface Product {
  id: number;
  name: string;
  author: string;
  status: 'active' | 'pending' | 'rejected';
  sales: number;
  price: number;
  category: string;
  description: string;
}

interface Stats {
  label: string;
  value: string;
  change: string;
}

export default function AdminDashboard() {
  const [activeTab, setActiveTab] = useState('overview');
  const [searchQuery, setSearchQuery] = useState('');
  const [isLoading, setIsLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);

  // State for form data
  const [newProduct, setNewProduct] = useState({
    name: '',
    price: '',
    category: '',
    description: ''
  });

  const [newUser, setNewUser] = useState({
    name: '',
    email: '',
    role: 'user',
    password: ''
  });

  // Example data - in a real app, this would come from an API
  const [stats, setStats] = useState<Stats[]>([
    { label: 'Total Users', value: '2,543', change: '+12%' },
    { label: 'Active Products', value: '1,234', change: '+5%' },
    { label: 'Total Sales', value: '$45,678', change: '+8%' },
    { label: 'Pending Reviews', value: '23', change: '-3' }
  ]);

  const [users, setUsers] = useState<User[]>([
    { id: 1, name: 'John Doe', email: 'john@example.com', role: 'Developer', joined: '2 hours ago', status: 'active' },
    { id: 2, name: 'Jane Smith', email: 'jane@example.com', role: 'Creator', joined: '5 hours ago', status: 'pending' },
    { id: 3, name: 'Mike Johnson', email: 'mike@example.com', role: 'Developer', joined: '1 day ago', status: 'active' }
  ]);

  const [products, setProducts] = useState<Product[]>([
    { id: 1, name: 'Advanced Combat System', author: 'DevPro', status: 'active', sales: 156, price: 29.99, category: 'Scripts', description: 'Advanced combat system with hit detection' },
    { id: 2, name: 'Castle Map', author: 'BuilderMaster', status: 'pending', sales: 89, price: 19.99, category: 'Maps', description: 'Detailed medieval castle map' },
    { id: 3, name: 'UI Kit', author: 'DesignPro', status: 'active', sales: 234, price: 14.99, category: 'UI', description: 'Modern UI components' }
  ]);

  // API Integration Functions
  const fetchStats = async () => {
    try {
      // const response = await fetch('/api/admin/stats');
      // const data = await response.json();
      // setStats(data);
      setIsLoading(false);
    } catch (err) {
      setError('Failed to fetch stats');
      setIsLoading(false);
    }
  };

  const fetchUsers = async () => {
    try {
      // const response = await fetch('/api/admin/users');
      // const data = await response.json();
      // setUsers(data);
    } catch (err) {
      setError('Failed to fetch users');
    }
  };

  const fetchProducts = async () => {
    try {
      // const response = await fetch('/api/admin/products');
      // const data = await response.json();
      // setProducts(data);
    } catch (err) {
      setError('Failed to fetch products');
    }
  };

  const handleCreateProduct = async (e: React.FormEvent) => {
    e.preventDefault();
    try {
      // const response = await fetch('/api/admin/products', {
      //   method: 'POST',
      //   headers: { 'Content-Type': 'application/json' },
      //   body: JSON.stringify(newProduct)
      // });
      // const data = await response.json();
      // setProducts([...products, data]);
      setNewProduct({ name: '', price: '', category: '', description: '' });
    } catch (err) {
      setError('Failed to create product');
    }
  };

  const handleCreateUser = async (e: React.FormEvent) => {
    e.preventDefault();
    try {
      // const response = await fetch('/api/admin/users', {
      //   method: 'POST',
      //   headers: { 'Content-Type': 'application/json' },
      //   body: JSON.stringify(newUser)
      // });
      // const data = await response.json();
      // setUsers([...users, data]);
      setNewUser({ name: '', email: '', role: 'user', password: '' });
    } catch (err) {
      setError('Failed to create user');
    }
  };

  const handleUpdateUserStatus = async (userId: number, newStatus: User['status']) => {
    try {
      // const response = await fetch(`/api/admin/users/${userId}`, {
      //   method: 'PATCH',
      //   headers: { 'Content-Type': 'application/json' },
      //   body: JSON.stringify({ status: newStatus })
      // });
      // const data = await response.json();
      // setUsers(users.map(user => user.id === userId ? data : user));
    } catch (err) {
      setError('Failed to update user status');
    }
  };

  const handleUpdateProductStatus = async (productId: number, newStatus: Product['status']) => {
    try {
      // const response = await fetch(`/api/admin/products/${productId}`, {
      //   method: 'PATCH',
      //   headers: { 'Content-Type': 'application/json' },
      //   body: JSON.stringify({ status: newStatus })
      // });
      // const data = await response.json();
      // setProducts(products.map(product => product.id === productId ? data : product));
    } catch (err) {
      setError('Failed to update product status');
    }
  };

  useEffect(() => {
    fetchStats();
    fetchUsers();
    fetchProducts();
  }, []);

  return (
    <div className="min-h-screen bg-gray-100">
      {/* Navbar */}
      <nav className="bg-white border-b border-gray-200 sticky top-0 shadow-sm">
        <div className="max-w-7xl mx-auto px-4 h-14 flex items-center justify-between">
          <div className="flex items-center">
            <Link href="/" className="text-slate-800 font-bold text-xl flex items-center">
              <span className="text-[#E60012]">Blox</span>
              <span>Bazaar</span>
            </Link>
          </div>
          
          <div className="hidden md:flex items-center space-x-1">
            <Link href="/marketplace" className="px-3 py-2 text-slate-600 rounded hover:bg-slate-50 flex items-center">
              <svg xmlns="http://www.w3.org/2000/svg" className="h-5 w-5 mr-1" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2">
                <path d="M3 3h18v18H3zM12 8v8m-4-4h8"></path>
              </svg>
              <span>Marketplace</span>
            </Link>

            <Link href="/forums" className="px-3 py-2 text-slate-600 rounded hover:bg-slate-50 flex items-center">
              <svg xmlns="http://www.w3.org/2000/svg" className="h-5 w-5 mr-1" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2">
                <path d="M21 15a2 2 0 0 1-2 2H7l-4 4V5a2 2 0 0 1 2-2h14a2 2 0 0 1 2 2z"></path>
              </svg>
              <span>Forums</span>
            </Link>
            
            <Link href="/learn" className="px-3 py-2 text-slate-600 rounded hover:bg-slate-50 flex items-center">
              <svg xmlns="http://www.w3.org/2000/svg" className="h-5 w-5 mr-1" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2">
                <path d="M2 3h6a4 4 0 0 1 4 4v14a3 3 0 0 0-3-3H2z"></path>
                <path d="M22 3h-6a4 4 0 0 0-4 4v14a3 3 0 0 1 3-3h7z"></path>
              </svg>
              <span>Learn</span>
            </Link>

            <div className="px-3 py-2 text-slate-600 rounded hover:bg-slate-50 flex items-center cursor-pointer group relative">
              <svg xmlns="http://www.w3.org/2000/svg" className="h-5 w-5 mr-1" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2">
                <circle cx="12" cy="12" r="3"></circle>
                <path d="M19.4 15a1.65 1.65 0 0 0 .33 1.82l.06.06a2 2 0 0 1 0 2.83 2 2 0 0 1-2.83 0l-.06-.06a1.65 1.65 0 0 0-1.82-.33 1.65 1.65 0 0 0-1 1.51V21a2 2 0 0 1-2 2 2 2 0 0 1-2-2v-.09A1.65 1.65 0 0 0 9 19.4a1.65 1.65 0 0 0-1.82.33l-.06.06a2 2 0 0 1-2.83 0 2 2 0 0 1 0-2.83l.06-.06a1.65 1.65 0 0 0 .33-1.82 1.65 1.65 0 0 0-1.51-1H3a2 2 0 0 1-2-2 2 2 0 0 1 2-2h.09A1.65 1.65 0 0 0 4.6 9a1.65 1.65 0 0 0-.33-1.82l-.06-.06a2 2 0 0 1 0-2.83 2 2 0 0 1 2.83 0l.06.06a1.65 1.65 0 0 0 1.82.33H9a1.65 1.65 0 0 0 1-1.51V3a2 2 0 0 1 2-2 2 2 0 0 1 2 2v.09a1.65 1.65 0 0 0 1 1.51 1.65 1.65 0 0 0 1.82-.33l.06-.06a2 2 0 0 1 2.83 0 2 2 0 0 1 0 2.83l-.06.06a1.65 1.65 0 0 0-.33 1.82V9a1.65 1.65 0 0 0 1.51 1H21a2 2 0 0 1 2 2 2 2 0 0 1-2 2h-.09a1.65 1.65 0 0 0-1.51 1z"></path>
              </svg>
              <span>Resources</span>
              <svg xmlns="http://www.w3.org/2000/svg" className="h-4 w-4 ml-1" viewBox="0 0 20 20" fill="currentColor">
                <path fillRule="evenodd" d="M5.293 7.293a1 1 0 011.414 0L10 10.586l3.293-3.293a1 1 0 111.414 1.414l-4 4a1 1 0 01-1.414 0l-4-4a1 1 0 010-1.414z" clipRule="evenodd" />
              </svg>
            </div>
          </div>
          
          <div className="flex items-center space-x-3">
            <Link href="/go-pro" className="bg-[#E60012] text-white px-4 sm:px-6 py-2 rounded text-sm font-medium flex items-center hover:bg-[#CC0000] transition">
              <svg xmlns="http://www.w3.org/2000/svg" className="h-5 w-5 mr-1" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2">
                <path d="M12 2L2 7l10 5 10-5-10-5zM2 17l10 5 10-5M2 12l10 5 10-5"></path>
              </svg>
              <span>Go Pro</span>
            </Link>
            
            <div className="flex items-center space-x-2">
              <Link href="/account" className="w-8 h-8 rounded-full bg-slate-800 text-white flex items-center justify-center font-bold hover:bg-slate-700 transition">
                A
              </Link>
            </div>
          </div>
        </div>
      </nav>

      {/* Admin Header */}
      <div className="bg-gradient-to-r from-slate-800 to-slate-900 py-8">
        <div className="max-w-7xl mx-auto px-4">
          <div className="flex items-center justify-between">
            <div>
              <h1 className="text-2xl font-bold text-white">Admin Dashboard</h1>
              <p className="text-slate-300 mt-1">Manage your BloxBazaar platform</p>
            </div>
            <div className="relative">
              <input
                type="text"
                placeholder="Search..."
                className="w-64 px-4 py-2 rounded-lg bg-white/10 border border-white/20 text-white placeholder-white/60 focus:outline-none focus:ring-2 focus:ring-white/30"
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
              />
              <button className="absolute right-3 top-1/2 -translate-y-1/2 text-white/60 hover:text-white">
                <svg xmlns="http://www.w3.org/2000/svg" className="h-5 w-5" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2">
                  <circle cx="11" cy="11" r="8"></circle>
                  <line x1="21" y1="21" x2="16.65" y2="16.65"></line>
                </svg>
              </button>
            </div>
          </div>
        </div>
      </div>

      {/* Main Content */}
      <main className="max-w-7xl mx-auto px-4 py-8">
        {/* Error Message */}
        {error && (
          <div className="bg-red-50 border-l-4 border-red-500 p-4 mb-6">
            <div className="flex">
              <div className="flex-shrink-0">
                <svg className="h-5 w-5 text-red-500" viewBox="0 0 20 20" fill="currentColor">
                  <path fillRule="evenodd" d="M10 18a8 8 0 100-16 8 8 0 000 16zM8.707 7.293a1 1 0 00-1.414 1.414L8.586 10l-1.293 1.293a1 1 0 101.414 1.414L10 11.414l1.293 1.293a1 1 0 001.414-1.414L11.414 10l1.293-1.293a1 1 0 00-1.414-1.414L10 8.586 8.707 7.293z" clipRule="evenodd" />
                </svg>
              </div>
              <div className="ml-3">
                <p className="text-sm text-red-700">{error}</p>
              </div>
            </div>
          </div>
        )}

        {/* Stats Grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 mb-8">
          {stats.map((stat) => (
            <div key={stat.label} className="bg-white rounded-lg shadow p-6">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm text-slate-600">{stat.label}</p>
                  <p className="text-2xl font-semibold text-slate-800 mt-1">{stat.value}</p>
                </div>
                <span className={`text-sm font-medium ${
                  stat.change.startsWith('+') ? 'text-green-600' : 'text-red-600'
                }`}>
                  {stat.change}
                </span>
              </div>
            </div>
          ))}
        </div>

        {/* Tabs */}
        <div className="bg-white rounded-lg shadow mb-8">
          <div className="border-b border-gray-200">
            <nav className="flex -mb-px">
              {['Overview', 'Users', 'Products', 'Sales', 'Settings'].map((tab) => (
                <button
                  key={tab}
                  className={`px-4 py-3 text-sm font-medium ${
                    activeTab === tab.toLowerCase()
                      ? 'border-b-2 border-[#E60012] text-[#E60012]'
                      : 'text-slate-600 hover:text-slate-800 hover:border-slate-300'
                  }`}
                  onClick={() => setActiveTab(tab.toLowerCase())}
                >
                  {tab}
                </button>
              ))}
            </nav>
          </div>

          {/* Tab Content */}
          <div className="p-6">
            {activeTab === 'overview' && (
              <div className="space-y-6">
                {/* Recent Users */}
                <div>
                  <h3 className="text-lg font-semibold text-slate-800 mb-4">Recent Users</h3>
                  <div className="bg-slate-50 rounded-lg overflow-hidden">
                    <table className="min-w-full divide-y divide-gray-200">
                      <thead className="bg-slate-100">
                        <tr>
                          <th className="px-6 py-3 text-left text-xs font-medium text-slate-600 uppercase tracking-wider">Name</th>
                          <th className="px-6 py-3 text-left text-xs font-medium text-slate-600 uppercase tracking-wider">Email</th>
                          <th className="px-6 py-3 text-left text-xs font-medium text-slate-600 uppercase tracking-wider">Role</th>
                          <th className="px-6 py-3 text-left text-xs font-medium text-slate-600 uppercase tracking-wider">Joined</th>
                        </tr>
                      </thead>
                      <tbody className="bg-white divide-y divide-gray-200">
                        {users.map((user) => (
                          <tr key={user.id}>
                            <td className="px-6 py-4 whitespace-nowrap text-sm text-slate-800">{user.name}</td>
                            <td className="px-6 py-4 whitespace-nowrap text-sm text-slate-600">{user.email}</td>
                            <td className="px-6 py-4 whitespace-nowrap text-sm text-slate-600">{user.role}</td>
                            <td className="px-6 py-4 whitespace-nowrap text-sm text-slate-600">{user.joined}</td>
                          </tr>
                        ))}
                      </tbody>
                    </table>
                  </div>
                </div>

                {/* Recent Products */}
                <div>
                  <h3 className="text-lg font-semibold text-slate-800 mb-4">Recent Products</h3>
                  <div className="bg-slate-50 rounded-lg overflow-hidden">
                    <table className="min-w-full divide-y divide-gray-200">
                      <thead className="bg-slate-100">
                        <tr>
                          <th className="px-6 py-3 text-left text-xs font-medium text-slate-600 uppercase tracking-wider">Name</th>
                          <th className="px-6 py-3 text-left text-xs font-medium text-slate-600 uppercase tracking-wider">Author</th>
                          <th className="px-6 py-3 text-left text-xs font-medium text-slate-600 uppercase tracking-wider">Status</th>
                          <th className="px-6 py-3 text-left text-xs font-medium text-slate-600 uppercase tracking-wider">Sales</th>
                        </tr>
                      </thead>
                      <tbody className="bg-white divide-y divide-gray-200">
                        {products.map((product) => (
                          <tr key={product.id}>
                            <td className="px-6 py-4 whitespace-nowrap text-sm text-slate-800">{product.name}</td>
                            <td className="px-6 py-4 whitespace-nowrap text-sm text-slate-600">{product.author}</td>
                            <td className="px-6 py-4 whitespace-nowrap">
                              <span className={`px-2 py-1 text-xs font-medium rounded-full ${
                                product.status === 'active' ? 'bg-green-100 text-green-800' : 'bg-yellow-100 text-yellow-800'
                              }`}>
                                {product.status}
                              </span>
                            </td>
                            <td className="px-6 py-4 whitespace-nowrap text-sm text-slate-600">{product.sales}</td>
                          </tr>
                        ))}
                      </tbody>
                    </table>
                  </div>
                </div>
              </div>
            )}

            {activeTab === 'users' && (
              <div className="space-y-6">
                {/* Create User Form */}
                <div className="bg-slate-50 rounded-lg p-6 mb-6">
                  <h3 className="text-lg font-semibold text-slate-800 mb-4">Create New User</h3>
                  <form onSubmit={handleCreateUser} className="space-y-4">
                    <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                      <div>
                        <label className="block text-sm font-medium text-slate-700">Name</label>
                        <input
                          type="text"
                          value={newUser.name}
                          onChange={(e) => setNewUser({ ...newUser, name: e.target.value })}
                          className="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-[#E60012] focus:ring-[#E60012]"
                          required
                        />
                      </div>
                      <div>
                        <label className="block text-sm font-medium text-slate-700">Email</label>
                        <input
                          type="email"
                          value={newUser.email}
                          onChange={(e) => setNewUser({ ...newUser, email: e.target.value })}
                          className="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-[#E60012] focus:ring-[#E60012]"
                          required
                        />
                      </div>
                      <div>
                        <label className="block text-sm font-medium text-slate-700">Role</label>
                        <select
                          value={newUser.role}
                          onChange={(e) => setNewUser({ ...newUser, role: e.target.value })}
                          className="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-[#E60012] focus:ring-[#E60012]"
                        >
                          <option value="user">User</option>
                          <option value="developer">Developer</option>
                          <option value="creator">Creator</option>
                          <option value="admin">Admin</option>
                        </select>
                      </div>
                      <div>
                        <label className="block text-sm font-medium text-slate-700">Password</label>
                        <input
                          type="password"
                          value={newUser.password}
                          onChange={(e) => setNewUser({ ...newUser, password: e.target.value })}
                          className="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-[#E60012] focus:ring-[#E60012]"
                          required
                        />
                      </div>
                    </div>
                    <button
                      type="submit"
                      className="bg-[#E60012] text-white px-4 py-2 rounded-md hover:bg-[#CC0000] transition"
                    >
                      Create User
                    </button>
                  </form>
                </div>

                {/* Users Table */}
                <div className="bg-slate-50 rounded-lg overflow-hidden">
                  <table className="min-w-full divide-y divide-gray-200">
                    <thead className="bg-slate-100">
                      <tr>
                        <th className="px-6 py-3 text-left text-xs font-medium text-slate-600 uppercase tracking-wider">Name</th>
                        <th className="px-6 py-3 text-left text-xs font-medium text-slate-600 uppercase tracking-wider">Email</th>
                        <th className="px-6 py-3 text-left text-xs font-medium text-slate-600 uppercase tracking-wider">Role</th>
                        <th className="px-6 py-3 text-left text-xs font-medium text-slate-600 uppercase tracking-wider">Status</th>
                        <th className="px-6 py-3 text-left text-xs font-medium text-slate-600 uppercase tracking-wider">Actions</th>
                      </tr>
                    </thead>
                    <tbody className="bg-white divide-y divide-gray-200">
                      {users.map((user) => (
                        <tr key={user.id}>
                          <td className="px-6 py-4 whitespace-nowrap text-sm text-slate-800">{user.name}</td>
                          <td className="px-6 py-4 whitespace-nowrap text-sm text-slate-600">{user.email}</td>
                          <td className="px-6 py-4 whitespace-nowrap text-sm text-slate-600">{user.role}</td>
                          <td className="px-6 py-4 whitespace-nowrap">
                            <span className={`px-2 py-1 text-xs font-medium rounded-full ${
                              user.status === 'active' ? 'bg-green-100 text-green-800' :
                              user.status === 'suspended' ? 'bg-red-100 text-red-800' :
                              'bg-yellow-100 text-yellow-800'
                            }`}>
                              {user.status}
                            </span>
                          </td>
                          <td className="px-6 py-4 whitespace-nowrap text-sm text-slate-600">
                            <select
                              value={user.status}
                              onChange={(e) => handleUpdateUserStatus(user.id, e.target.value as User['status'])}
                              className="rounded-md border-gray-300 shadow-sm focus:border-[#E60012] focus:ring-[#E60012]"
                            >
                              <option value="active">Active</option>
                              <option value="suspended">Suspend</option>
                              <option value="pending">Pending</option>
                            </select>
                          </td>
                        </tr>
                      ))}
                    </tbody>
                  </table>
                </div>
              </div>
            )}

            {activeTab === 'products' && (
              <div className="space-y-6">
                {/* Create Product Form */}
                <div className="bg-slate-50 rounded-lg p-6 mb-6">
                  <h3 className="text-lg font-semibold text-slate-800 mb-4">Create New Product</h3>
                  <form onSubmit={handleCreateProduct} className="space-y-4">
                    <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                      <div>
                        <label className="block text-sm font-medium text-slate-700">Name</label>
                        <input
                          type="text"
                          value={newProduct.name}
                          onChange={(e) => setNewProduct({ ...newProduct, name: e.target.value })}
                          className="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-[#E60012] focus:ring-[#E60012]"
                          required
                        />
                      </div>
                      <div>
                        <label className="block text-sm font-medium text-slate-700">Price</label>
                        <input
                          type="number"
                          step="0.01"
                          value={newProduct.price}
                          onChange={(e) => setNewProduct({ ...newProduct, price: e.target.value })}
                          className="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-[#E60012] focus:ring-[#E60012]"
                          required
                        />
                      </div>
                      <div>
                        <label className="block text-sm font-medium text-slate-700">Category</label>
                        <select
                          value={newProduct.category}
                          onChange={(e) => setNewProduct({ ...newProduct, category: e.target.value })}
                          className="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-[#E60012] focus:ring-[#E60012]"
                          required
                        >
                          <option value="">Select a category</option>
                          <option value="Scripts">Scripts</option>
                          <option value="Maps">Maps</option>
                          <option value="Models">Models</option>
                          <option value="UI">UI</option>
                          <option value="Animations">Animations</option>
                        </select>
                      </div>
                      <div>
                        <label className="block text-sm font-medium text-slate-700">Description</label>
                        <textarea
                          value={newProduct.description}
                          onChange={(e) => setNewProduct({ ...newProduct, description: e.target.value })}
                          className="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-[#E60012] focus:ring-[#E60012]"
                          rows={3}
                          required
                        />
                      </div>
                    </div>
                    <button
                      type="submit"
                      className="bg-[#E60012] text-white px-4 py-2 rounded-md hover:bg-[#CC0000] transition"
                    >
                      Create Product
                    </button>
                  </form>
                </div>

                {/* Products Table */}
                <div className="bg-slate-50 rounded-lg overflow-hidden">
                  <table className="min-w-full divide-y divide-gray-200">
                    <thead className="bg-slate-100">
                      <tr>
                        <th className="px-6 py-3 text-left text-xs font-medium text-slate-600 uppercase tracking-wider">Name</th>
                        <th className="px-6 py-3 text-left text-xs font-medium text-slate-600 uppercase tracking-wider">Author</th>
                        <th className="px-6 py-3 text-left text-xs font-medium text-slate-600 uppercase tracking-wider">Category</th>
                        <th className="px-6 py-3 text-left text-xs font-medium text-slate-600 uppercase tracking-wider">Status</th>
                        <th className="px-6 py-3 text-left text-xs font-medium text-slate-600 uppercase tracking-wider">Actions</th>
                      </tr>
                    </thead>
                    <tbody className="bg-white divide-y divide-gray-200">
                      {products.map((product) => (
                        <tr key={product.id}>
                          <td className="px-6 py-4 whitespace-nowrap text-sm text-slate-800">{product.name}</td>
                          <td className="px-6 py-4 whitespace-nowrap text-sm text-slate-600">{product.author}</td>
                          <td className="px-6 py-4 whitespace-nowrap text-sm text-slate-600">{product.category}</td>
                          <td className="px-6 py-4 whitespace-nowrap">
                            <span className={`px-2 py-1 text-xs font-medium rounded-full ${
                              product.status === 'active' ? 'bg-green-100 text-green-800' :
                              product.status === 'pending' ? 'bg-yellow-100 text-yellow-800' :
                              'bg-red-100 text-red-800'
                            }`}>
                              {product.status}
                            </span>
                          </td>
                          <td className="px-6 py-4 whitespace-nowrap text-sm text-slate-600">
                            <select
                              value={product.status}
                              onChange={(e) => handleUpdateProductStatus(product.id, e.target.value as Product['status'])}
                              className="rounded-md border-gray-300 shadow-sm focus:border-[#E60012] focus:ring-[#E60012]"
                            >
                              <option value="active">Active</option>
                              <option value="pending">Pending</option>
                              <option value="rejected">Reject</option>
                            </select>
                          </td>
                        </tr>
                      ))}
                    </tbody>
                  </table>
                </div>
              </div>
            )}

            {activeTab === 'settings' && (
              <div className="space-y-6">
                <div className="bg-slate-50 rounded-lg p-6">
                  <h3 className="text-lg font-semibold text-slate-800 mb-4">Platform Settings</h3>
                  <div className="space-y-4">
                    <div>
                      <label className="block text-sm font-medium text-slate-700">Maintenance Mode</label>
                      <div className="mt-2">
                        <label className="inline-flex items-center">
                          <input type="checkbox" className="rounded border-gray-300 text-[#E60012] focus:ring-[#E60012]" />
                          <span className="ml-2 text-sm text-slate-600">Enable maintenance mode</span>
                        </label>
                      </div>
                    </div>
                    <div>
                      <label className="block text-sm font-medium text-slate-700">Registration</label>
                      <div className="mt-2">
                        <label className="inline-flex items-center">
                          <input type="checkbox" className="rounded border-gray-300 text-[#E60012] focus:ring-[#E60012]" defaultChecked />
                          <span className="ml-2 text-sm text-slate-600">Allow new user registration</span>
                        </label>
                      </div>
                    </div>
                    <div>
                      <label className="block text-sm font-medium text-slate-700">Product Approval</label>
                      <div className="mt-2">
                        <label className="inline-flex items-center">
                          <input type="checkbox" className="rounded border-gray-300 text-[#E60012] focus:ring-[#E60012]" defaultChecked />
                          <span className="ml-2 text-sm text-slate-600">Require admin approval for new products</span>
                        </label>
                      </div>
                    </div>
                    <div>
                      <label className="block text-sm font-medium text-slate-700">API Key</label>
                      <div className="mt-2">
                        <input
                          type="text"
                          className="block w-full rounded-md border-gray-300 shadow-sm focus:border-[#E60012] focus:ring-[#E60012]"
                          placeholder="Enter your API key"
                        />
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            )}
          </div>
        </div>
      </main>
    </div>
  );
} 