'use client'

import { useState } from 'react';
import Link from 'next/link';
import Image from 'next/image';

interface Product {
  id: string;
  title: string;
  price: number;
  category: string;
  image: string;
  sales: number;
  rating: number;
  status: 'draft' | 'published' | 'archived';
}

interface StoreStats {
  totalProducts: number;
  totalSales: number;
  totalRevenue: number;
  averageRating: number;
}

export default function Storefront() {
  const [activeTab, setActiveTab] = useState('overview');
  const [storeName, setStoreName] = useState('My Store');
  const [storeDescription, setStoreDescription] = useState('Welcome to my Roblox development store!');
  const [storeBanner, setStoreBanner] = useState('https://placehold.co/1200x300/1e293b/ffffff?text=Store+Banner');
  const [storeLogo, setStoreLogo] = useState('https://placehold.co/200x200/1e293b/ffffff?text=Logo');

  const [stats, setStats] = useState<StoreStats>({
    totalProducts: 12,
    totalSales: 156,
    totalRevenue: 1248,
    averageRating: 4.8
  });

  const [products, setProducts] = useState<Product[]>([
    {
      id: '1',
      title: 'Advanced Combat System',
      price: 29.99,
      category: 'Scripts',
      image: 'https://placehold.co/400x300/1e293b/ffffff?text=Combat+System',
      sales: 45,
      rating: 4.9,
      status: 'published'
    },
    {
      id: '2',
      title: 'Medieval Castle Map',
      price: 19.99,
      category: 'Maps',
      image: 'https://placehold.co/400x300/1e293b/ffffff?text=Castle+Map',
      sales: 32,
      rating: 4.7,
      status: 'published'
    }
  ]);

  return (
    <div className="min-h-screen bg-gray-100">
      {/* Navbar */}
      <nav className="bg-white border-b border-gray-200 sticky top-0 shadow-sm">
        <div className="max-w-7xl mx-auto px-4 h-14 flex items-center justify-between">
          <div className="flex items-center">
            <Link href="/" className="text-slate-800 font-bold text-xl flex items-center">
              <span className="text-[#E60012]">Blox</span>
              <span>Bazaar</span>
            </Link>
          </div>
          
          <div className="hidden md:flex items-center space-x-1">
            <Link href="/marketplace" className="px-3 py-2 text-slate-600 rounded hover:bg-slate-50 flex items-center">
              <svg xmlns="http://www.w3.org/2000/svg" className="h-5 w-5 mr-1" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2">
                <path d="M3 3h18v18H3zM12 8v8m-4-4h8"></path>
              </svg>
              <span>Marketplace</span>
            </Link>

            <Link href="/forums" className="px-3 py-2 text-slate-600 rounded hover:bg-slate-50 flex items-center">
              <svg xmlns="http://www.w3.org/2000/svg" className="h-5 w-5 mr-1" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2">
                <path d="M21 15a2 2 0 0 1-2 2H7l-4 4V5a2 2 0 0 1 2-2h14a2 2 0 0 1 2 2z"></path>
              </svg>
              <span>Forums</span>
            </Link>
            
            <Link href="/learn" className="px-3 py-2 text-slate-600 rounded hover:bg-slate-50 flex items-center">
              <svg xmlns="http://www.w3.org/2000/svg" className="h-5 w-5 mr-1" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2">
                <path d="M2 3h6a4 4 0 0 1 4 4v14a3 3 0 0 0-3-3H2z"></path>
                <path d="M22 3h-6a4 4 0 0 0-4 4v14a3 3 0 0 1 3-3h7z"></path>
              </svg>
              <span>Learn</span>
            </Link>
          </div>
          
          <div className="flex items-center space-x-3">
            <Link href="/go-pro" className="bg-[#E60012] text-white px-4 sm:px-6 py-2 rounded text-sm font-medium flex items-center hover:bg-[#CC0000] transition">
              <svg xmlns="http://www.w3.org/2000/svg" className="h-5 w-5 mr-1" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2">
                <path d="M12 2L2 7l10 5 10-5-10-5zM2 17l10 5 10-5M2 12l10 5 10-5"></path>
              </svg>
              <span>Go Pro</span>
            </Link>
            
            <div className="flex items-center space-x-2">
              <Link href="/account" className="w-8 h-8 rounded-full bg-slate-800 text-white flex items-center justify-center font-bold hover:bg-slate-700 transition">
                A
              </Link>
            </div>
          </div>
        </div>
      </nav>

      {/* Store Header */}
      <div className="bg-gradient-to-r from-slate-800 to-slate-900 py-12">
        <div className="max-w-7xl mx-auto px-4">
          <div className="flex flex-col md:flex-row items-center justify-between">
            <div className="flex items-center space-x-4 mb-4 md:mb-0">
              <div className="w-20 h-20 rounded-full bg-white overflow-hidden">
                <Image
                  src={storeLogo}
                  alt="Store Logo"
                  width={80}
                  height={80}
                  className="object-cover"
                />
              </div>
              <div>
                <h1 className="text-3xl font-bold text-white">{storeName}</h1>
                <p className="text-slate-300">{storeDescription}</p>
              </div>
            </div>
            <div className="flex space-x-4">
              <button className="bg-white text-slate-800 px-4 py-2 rounded-lg font-medium hover:bg-slate-100 transition">
                Edit Store
              </button>
              <button className="bg-[#E60012] text-white px-4 py-2 rounded-lg font-medium hover:bg-[#CC0000] transition">
                Add Product
              </button>
            </div>
          </div>
        </div>
      </div>

      {/* Store Navigation */}
      <div className="bg-white border-b border-gray-200">
        <div className="max-w-7xl mx-auto px-4">
          <nav className="flex space-x-8 py-4">
            <button
              onClick={() => setActiveTab('overview')}
              className={`px-3 py-2 text-sm font-medium ${
                activeTab === 'overview'
                  ? 'text-[#E60012] border-b-2 border-[#E60012]'
                  : 'text-slate-600 hover:text-slate-800'
              }`}
            >
              Overview
            </button>
            <button
              onClick={() => setActiveTab('products')}
              className={`px-3 py-2 text-sm font-medium ${
                activeTab === 'products'
                  ? 'text-[#E60012] border-b-2 border-[#E60012]'
                  : 'text-slate-600 hover:text-slate-800'
              }`}
            >
              Products
            </button>
            <button
              onClick={() => setActiveTab('analytics')}
              className={`px-3 py-2 text-sm font-medium ${
                activeTab === 'analytics'
                  ? 'text-[#E60012] border-b-2 border-[#E60012]'
                  : 'text-slate-600 hover:text-slate-800'
              }`}
            >
              Analytics
            </button>
            <button
              onClick={() => setActiveTab('settings')}
              className={`px-3 py-2 text-sm font-medium ${
                activeTab === 'settings'
                  ? 'text-[#E60012] border-b-2 border-[#E60012]'
                  : 'text-slate-600 hover:text-slate-800'
              }`}
            >
              Settings
            </button>
          </nav>
        </div>
      </div>

      {/* Main Content */}
      <main className="max-w-7xl mx-auto px-4 py-8">
        {activeTab === 'overview' && (
          <div className="space-y-8">
            {/* Stats Cards */}
            <div className="grid grid-cols-1 md:grid-cols-4 gap-6">
              <div className="bg-white rounded-lg shadow p-6">
                <h3 className="text-slate-600 text-sm font-medium">Total Products</h3>
                <p className="text-3xl font-bold text-slate-800">{stats.totalProducts}</p>
              </div>
              <div className="bg-white rounded-lg shadow p-6">
                <h3 className="text-slate-600 text-sm font-medium">Total Sales</h3>
                <p className="text-3xl font-bold text-slate-800">{stats.totalSales}</p>
              </div>
              <div className="bg-white rounded-lg shadow p-6">
                <h3 className="text-slate-600 text-sm font-medium">Total Revenue</h3>
                <p className="text-3xl font-bold text-slate-800">${stats.totalRevenue}</p>
              </div>
              <div className="bg-white rounded-lg shadow p-6">
                <h3 className="text-slate-600 text-sm font-medium">Average Rating</h3>
                <p className="text-3xl font-bold text-slate-800">{stats.averageRating}</p>
              </div>
            </div>

            {/* Recent Products */}
            <div className="bg-white rounded-lg shadow">
              <div className="p-6 border-b border-gray-200">
                <h2 className="text-xl font-semibold text-slate-800">Recent Products</h2>
              </div>
              <div className="p-6">
                <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
                  {products.map((product) => (
                    <div key={product.id} className="bg-slate-50 rounded-lg overflow-hidden">
                      <div className="relative h-48">
                        <Image
                          src={product.image}
                          alt={product.title}
                          fill
                          className="object-cover"
                        />
                      </div>
                      <div className="p-4">
                        <h3 className="font-semibold text-slate-800">{product.title}</h3>
                        <p className="text-[#E60012] font-bold">${product.price}</p>
                        <div className="flex items-center justify-between mt-2">
                          <span className="text-sm text-slate-600">{product.sales} sales</span>
                          <span className="text-sm text-slate-600">{product.rating} ★</span>
                        </div>
                      </div>
                    </div>
                  ))}
                </div>
              </div>
            </div>
          </div>
        )}

        {activeTab === 'products' && (
          <div className="bg-white rounded-lg shadow">
            <div className="p-6 border-b border-gray-200 flex justify-between items-center">
              <h2 className="text-xl font-semibold text-slate-800">Products</h2>
              <button className="bg-[#E60012] text-white px-4 py-2 rounded-lg font-medium hover:bg-[#CC0000] transition">
                Add New Product
              </button>
            </div>
            <div className="p-6">
              <div className="overflow-x-auto">
                <table className="min-w-full divide-y divide-gray-200">
                  <thead>
                    <tr>
                      <th className="px-6 py-3 text-left text-xs font-medium text-slate-500 uppercase tracking-wider">
                        Product
                      </th>
                      <th className="px-6 py-3 text-left text-xs font-medium text-slate-500 uppercase tracking-wider">
                        Category
                      </th>
                      <th className="px-6 py-3 text-left text-xs font-medium text-slate-500 uppercase tracking-wider">
                        Price
                      </th>
                      <th className="px-6 py-3 text-left text-xs font-medium text-slate-500 uppercase tracking-wider">
                        Sales
                      </th>
                      <th className="px-6 py-3 text-left text-xs font-medium text-slate-500 uppercase tracking-wider">
                        Status
                      </th>
                      <th className="px-6 py-3 text-left text-xs font-medium text-slate-500 uppercase tracking-wider">
                        Actions
                      </th>
                    </tr>
                  </thead>
                  <tbody className="bg-white divide-y divide-gray-200">
                    {products.map((product) => (
                      <tr key={product.id}>
                        <td className="px-6 py-4 whitespace-nowrap">
                          <div className="flex items-center">
                            <div className="flex-shrink-0 h-10 w-10">
                              <Image
                                src={product.image}
                                alt={product.title}
                                width={40}
                                height={40}
                                className="rounded-full"
                              />
                            </div>
                            <div className="ml-4">
                              <div className="text-sm font-medium text-slate-900">
                                {product.title}
                              </div>
                            </div>
                          </div>
                        </td>
                        <td className="px-6 py-4 whitespace-nowrap">
                          <div className="text-sm text-slate-900">{product.category}</div>
                        </td>
                        <td className="px-6 py-4 whitespace-nowrap">
                          <div className="text-sm text-slate-900">${product.price}</div>
                        </td>
                        <td className="px-6 py-4 whitespace-nowrap">
                          <div className="text-sm text-slate-900">{product.sales}</div>
                        </td>
                        <td className="px-6 py-4 whitespace-nowrap">
                          <span className={`px-2 inline-flex text-xs leading-5 font-semibold rounded-full ${
                            product.status === 'published'
                              ? 'bg-green-100 text-green-800'
                              : product.status === 'draft'
                              ? 'bg-yellow-100 text-yellow-800'
                              : 'bg-red-100 text-red-800'
                          }`}>
                            {product.status}
                          </span>
                        </td>
                        <td className="px-6 py-4 whitespace-nowrap text-sm font-medium">
                          <button className="text-[#E60012] hover:text-[#CC0000] mr-3">
                            Edit
                          </button>
                          <button className="text-slate-600 hover:text-slate-800">
                            Delete
                          </button>
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            </div>
          </div>
        )}

        {activeTab === 'analytics' && (
          <div className="space-y-8">
            {/* Analytics Overview */}
            <div className="bg-white rounded-lg shadow p-6">
              <h2 className="text-xl font-semibold text-slate-800 mb-4">Analytics Overview</h2>
              <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                <div className="bg-slate-50 rounded-lg p-4">
                  <h3 className="text-lg font-medium text-slate-800 mb-2">Sales Trend</h3>
                  <div className="h-64 bg-white rounded border border-gray-200">
                    {/* Chart placeholder */}
                    <div className="flex items-center justify-center h-full text-slate-400">
                      Sales Chart
                    </div>
                  </div>
                </div>
                <div className="bg-slate-50 rounded-lg p-4">
                  <h3 className="text-lg font-medium text-slate-800 mb-2">Revenue by Product</h3>
                  <div className="h-64 bg-white rounded border border-gray-200">
                    {/* Chart placeholder */}
                    <div className="flex items-center justify-center h-full text-slate-400">
                      Revenue Chart
                    </div>
                  </div>
                </div>
              </div>
            </div>

            {/* Top Products */}
            <div className="bg-white rounded-lg shadow">
              <div className="p-6 border-b border-gray-200">
                <h2 className="text-xl font-semibold text-slate-800">Top Performing Products</h2>
              </div>
              <div className="p-6">
                <div className="space-y-4">
                  {products.map((product) => (
                    <div key={product.id} className="flex items-center justify-between">
                      <div className="flex items-center space-x-4">
                        <div className="w-12 h-12 rounded overflow-hidden">
                          <Image
                            src={product.image}
                            alt={product.title}
                            width={48}
                            height={48}
                            className="object-cover"
                          />
                        </div>
                        <div>
                          <h3 className="font-medium text-slate-800">{product.title}</h3>
                          <p className="text-sm text-slate-600">{product.category}</p>
                        </div>
                      </div>
                      <div className="text-right">
                        <p className="font-medium text-slate-800">${product.price * product.sales}</p>
                        <p className="text-sm text-slate-600">{product.sales} sales</p>
                      </div>
                    </div>
                  ))}
                </div>
              </div>
            </div>
          </div>
        )}

        {activeTab === 'settings' && (
          <div className="bg-white rounded-lg shadow">
            <div className="p-6 border-b border-gray-200">
              <h2 className="text-xl font-semibold text-slate-800">Store Settings</h2>
            </div>
            <div className="p-6">
              <div className="space-y-6">
                <div>
                  <label className="block text-sm font-medium text-slate-700">Store Name</label>
                  <input
                    type="text"
                    value={storeName}
                    onChange={(e) => setStoreName(e.target.value)}
                    className="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-[#E60012] focus:ring-[#E60012] sm:text-sm"
                  />
                </div>
                <div>
                  <label className="block text-sm font-medium text-slate-700">Store Description</label>
                  <textarea
                    value={storeDescription}
                    onChange={(e) => setStoreDescription(e.target.value)}
                    rows={3}
                    className="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-[#E60012] focus:ring-[#E60012] sm:text-sm"
                  />
                </div>
                <div>
                  <label className="block text-sm font-medium text-slate-700">Store Banner</label>
                  <div className="mt-1 flex items-center space-x-4">
                    <div className="w-full h-32 rounded-md overflow-hidden">
                      <Image
                        src={storeBanner}
                        alt="Store Banner"
                        width={1200}
                        height={300}
                        className="object-cover"
                      />
                    </div>
                    <button className="bg-slate-100 text-slate-800 px-4 py-2 rounded-md hover:bg-slate-200 transition">
                      Change
                    </button>
                  </div>
                </div>
                <div>
                  <label className="block text-sm font-medium text-slate-700">Store Logo</label>
                  <div className="mt-1 flex items-center space-x-4">
                    <div className="w-20 h-20 rounded-full overflow-hidden">
                      <Image
                        src={storeLogo}
                        alt="Store Logo"
                        width={80}
                        height={80}
                        className="object-cover"
                      />
                    </div>
                    <button className="bg-slate-100 text-slate-800 px-4 py-2 rounded-md hover:bg-slate-200 transition">
                      Change
                    </button>
                  </div>
                </div>
                <div className="flex justify-end">
                  <button className="bg-[#E60012] text-white px-6 py-2 rounded-lg font-medium hover:bg-[#CC0000] transition">
                    Save Changes
                  </button>
                </div>
              </div>
            </div>
          </div>
        )}
      </main>
    </div>
  );
} 