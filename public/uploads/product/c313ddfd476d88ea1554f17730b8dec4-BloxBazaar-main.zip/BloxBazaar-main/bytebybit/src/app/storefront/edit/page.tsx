'use client'

import { useState } from 'react';
import Link from 'next/link';
import Image from 'next/image';

interface StoreSettings {
  name: string;
  description: string;
  banner: string;
  logo: string;
  socialLinks: {
    discord?: string;
    twitter?: string;
    youtube?: string;
  };
  categories: string[];
  paymentMethods: string[];
  storeTheme: {
    primaryColor: string;
    secondaryColor: string;
    fontFamily: string;
  };
}

export default function EditStore() {
  const [settings, setSettings] = useState<StoreSettings>({
    name: 'My Store',
    description: 'Welcome to my Roblox development store!',
    banner: 'https://placehold.co/1200x300/1e293b/ffffff?text=Store+Banner',
    logo: 'https://placehold.co/200x200/1e293b/ffffff?text=Logo',
    socialLinks: {
      discord: 'https://discord.gg/example',
      twitter: 'https://twitter.com/example',
      youtube: 'https://youtube.com/example'
    },
    categories: ['Scripts', 'Maps', 'Models', 'Plugins'],
    paymentMethods: ['Robux', 'PayPal', 'Credit Card'],
    storeTheme: {
      primaryColor: '#E60012',
      secondaryColor: '#1e293b',
      fontFamily: 'Inter'
    }
  });

  const [activeSection, setActiveSection] = useState('general');

  return (
    <div className="min-h-screen bg-gray-100">
      {/* Navbar */}
      <nav className="bg-white border-b border-gray-200 sticky top-0 shadow-sm">
        <div className="max-w-7xl mx-auto px-4 h-14 flex items-center justify-between">
          <div className="flex items-center">
            <Link href="/" className="text-slate-800 font-bold text-xl flex items-center">
              <span className="text-[#E60012]">Blox</span>
              <span>Bazaar</span>
            </Link>
          </div>
          
          <div className="hidden md:flex items-center space-x-1">
            <Link href="/marketplace" className="px-3 py-2 text-slate-600 rounded hover:bg-slate-50 flex items-center">
              <svg xmlns="http://www.w3.org/2000/svg" className="h-5 w-5 mr-1" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2">
                <path d="M3 3h18v18H3zM12 8v8m-4-4h8"></path>
              </svg>
              <span>Marketplace</span>
            </Link>

            <Link href="/forums" className="px-3 py-2 text-slate-600 rounded hover:bg-slate-50 flex items-center">
              <svg xmlns="http://www.w3.org/2000/svg" className="h-5 w-5 mr-1" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2">
                <path d="M21 15a2 2 0 0 1-2 2H7l-4 4V5a2 2 0 0 1 2-2h14a2 2 0 0 1 2 2z"></path>
              </svg>
              <span>Forums</span>
            </Link>
            
            <Link href="/learn" className="px-3 py-2 text-slate-600 rounded hover:bg-slate-50 flex items-center">
              <svg xmlns="http://www.w3.org/2000/svg" className="h-5 w-5 mr-1" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2">
                <path d="M2 3h6a4 4 0 0 1 4 4v14a3 3 0 0 0-3-3H2z"></path>
                <path d="M22 3h-6a4 4 0 0 0-4 4v14a3 3 0 0 1 3-3h7z"></path>
              </svg>
              <span>Learn</span>
            </Link>
          </div>
          
          <div className="flex items-center space-x-3">
            <Link href="/go-pro" className="bg-[#E60012] text-white px-4 sm:px-6 py-2 rounded text-sm font-medium flex items-center hover:bg-[#CC0000] transition">
              <svg xmlns="http://www.w3.org/2000/svg" className="h-5 w-5 mr-1" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2">
                <path d="M12 2L2 7l10 5 10-5-10-5zM2 17l10 5 10-5M2 12l10 5 10-5"></path>
              </svg>
              <span>Go Pro</span>
            </Link>
            
            <div className="flex items-center space-x-2">
              <Link href="/account" className="w-8 h-8 rounded-full bg-slate-800 text-white flex items-center justify-center font-bold hover:bg-slate-700 transition">
                A
              </Link>
            </div>
          </div>
        </div>
      </nav>

      {/* Header */}
      <div className="bg-gradient-to-r from-slate-800 to-slate-900 py-12">
        <div className="max-w-7xl mx-auto px-4">
          <div className="flex items-center justify-between">
            <div>
              <h1 className="text-3xl font-bold text-white">Edit Store</h1>
              <p className="text-slate-300 mt-2">Customize your store settings and appearance</p>
            </div>
            <div className="flex space-x-4">
              <Link
                href="/storefront"
                className="bg-white text-slate-800 px-4 py-2 rounded-lg font-medium hover:bg-slate-100 transition"
              >
                Back to Store
              </Link>
              <button className="bg-[#E60012] text-white px-4 py-2 rounded-lg font-medium hover:bg-[#CC0000] transition">
                Save Changes
              </button>
            </div>
          </div>
        </div>
      </div>

      {/* Main Content */}
      <main className="max-w-7xl mx-auto px-4 py-8">
        <div className="flex flex-col md:flex-row gap-8">
          {/* Sidebar Navigation */}
          <div className="w-full md:w-64">
            <nav className="bg-white rounded-lg shadow overflow-hidden">
              <button
                onClick={() => setActiveSection('general')}
                className={`w-full px-4 py-3 text-left text-sm font-medium ${
                  activeSection === 'general'
                    ? 'bg-slate-50 text-[#E60012]'
                    : 'text-slate-600 hover:bg-slate-50'
                }`}
              >
                General Settings
              </button>
              <button
                onClick={() => setActiveSection('appearance')}
                className={`w-full px-4 py-3 text-left text-sm font-medium ${
                  activeSection === 'appearance'
                    ? 'bg-slate-50 text-[#E60012]'
                    : 'text-slate-600 hover:bg-slate-50'
                }`}
              >
                Appearance
              </button>
              <button
                onClick={() => setActiveSection('social')}
                className={`w-full px-4 py-3 text-left text-sm font-medium ${
                  activeSection === 'social'
                    ? 'bg-slate-50 text-[#E60012]'
                    : 'text-slate-600 hover:bg-slate-50'
                }`}
              >
                Social Links
              </button>
              <button
                onClick={() => setActiveSection('categories')}
                className={`w-full px-4 py-3 text-left text-sm font-medium ${
                  activeSection === 'categories'
                    ? 'bg-slate-50 text-[#E60012]'
                    : 'text-slate-600 hover:bg-slate-50'
                }`}
              >
                Categories
              </button>
              <button
                onClick={() => setActiveSection('payments')}
                className={`w-full px-4 py-3 text-left text-sm font-medium ${
                  activeSection === 'payments'
                    ? 'bg-slate-50 text-[#E60012]'
                    : 'text-slate-600 hover:bg-slate-50'
                }`}
              >
                Payment Methods
              </button>
            </nav>
          </div>

          {/* Content Area */}
          <div className="flex-1">
            {activeSection === 'general' && (
              <div className="bg-white rounded-lg shadow p-6">
                <h2 className="text-xl font-semibold text-slate-800 mb-6">General Settings</h2>
                <div className="space-y-6">
                  <div>
                    <label className="block text-sm font-medium text-slate-700">Store Name</label>
                    <input
                      type="text"
                      value={settings.name}
                      onChange={(e) => setSettings({ ...settings, name: e.target.value })}
                      className="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-[#E60012] focus:ring-[#E60012] sm:text-sm"
                    />
                  </div>
                  <div>
                    <label className="block text-sm font-medium text-slate-700">Store Description</label>
                    <textarea
                      value={settings.description}
                      onChange={(e) => setSettings({ ...settings, description: e.target.value })}
                      rows={3}
                      className="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-[#E60012] focus:ring-[#E60012] sm:text-sm"
                    />
                  </div>
                  <div>
                    <label className="block text-sm font-medium text-slate-700">Store Banner</label>
                    <div className="mt-1 flex items-center space-x-4">
                      <div className="w-full h-32 rounded-md overflow-hidden">
                        <Image
                          src={settings.banner}
                          alt="Store Banner"
                          width={1200}
                          height={300}
                          className="object-cover"
                        />
                      </div>
                      <button className="bg-slate-100 text-slate-800 px-4 py-2 rounded-md hover:bg-slate-200 transition">
                        Change
                      </button>
                    </div>
                  </div>
                  <div>
                    <label className="block text-sm font-medium text-slate-700">Store Logo</label>
                    <div className="mt-1 flex items-center space-x-4">
                      <div className="w-20 h-20 rounded-full overflow-hidden">
                        <Image
                          src={settings.logo}
                          alt="Store Logo"
                          width={80}
                          height={80}
                          className="object-cover"
                        />
                      </div>
                      <button className="bg-slate-100 text-slate-800 px-4 py-2 rounded-md hover:bg-slate-200 transition">
                        Change
                      </button>
                    </div>
                  </div>
                </div>
              </div>
            )}

            {activeSection === 'appearance' && (
              <div className="bg-white rounded-lg shadow p-6">
                <h2 className="text-xl font-semibold text-slate-800 mb-6">Appearance</h2>
                <div className="space-y-6">
                  <div>
                    <label className="block text-sm font-medium text-slate-700">Primary Color</label>
                    <div className="mt-1 flex items-center space-x-4">
                      <input
                        type="color"
                        value={settings.storeTheme.primaryColor}
                        onChange={(e) => setSettings({
                          ...settings,
                          storeTheme: { ...settings.storeTheme, primaryColor: e.target.value }
                        })}
                        className="h-10 w-20 rounded border border-gray-300"
                      />
                      <input
                        type="text"
                        value={settings.storeTheme.primaryColor}
                        onChange={(e) => setSettings({
                          ...settings,
                          storeTheme: { ...settings.storeTheme, primaryColor: e.target.value }
                        })}
                        className="block w-full rounded-md border-gray-300 shadow-sm focus:border-[#E60012] focus:ring-[#E60012] sm:text-sm"
                      />
                    </div>
                  </div>
                  <div>
                    <label className="block text-sm font-medium text-slate-700">Secondary Color</label>
                    <div className="mt-1 flex items-center space-x-4">
                      <input
                        type="color"
                        value={settings.storeTheme.secondaryColor}
                        onChange={(e) => setSettings({
                          ...settings,
                          storeTheme: { ...settings.storeTheme, secondaryColor: e.target.value }
                        })}
                        className="h-10 w-20 rounded border border-gray-300"
                      />
                      <input
                        type="text"
                        value={settings.storeTheme.secondaryColor}
                        onChange={(e) => setSettings({
                          ...settings,
                          storeTheme: { ...settings.storeTheme, secondaryColor: e.target.value }
                        })}
                        className="block w-full rounded-md border-gray-300 shadow-sm focus:border-[#E60012] focus:ring-[#E60012] sm:text-sm"
                      />
                    </div>
                  </div>
                  <div>
                    <label className="block text-sm font-medium text-slate-700">Font Family</label>
                    <select
                      value={settings.storeTheme.fontFamily}
                      onChange={(e) => setSettings({
                        ...settings,
                        storeTheme: { ...settings.storeTheme, fontFamily: e.target.value }
                      })}
                      className="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-[#E60012] focus:ring-[#E60012] sm:text-sm"
                    >
                      <option value="Inter">Inter</option>
                      <option value="Roboto">Roboto</option>
                      <option value="Open Sans">Open Sans</option>
                      <option value="Poppins">Poppins</option>
                    </select>
                  </div>
                </div>
              </div>
            )}

            {activeSection === 'social' && (
              <div className="bg-white rounded-lg shadow p-6">
                <h2 className="text-xl font-semibold text-slate-800 mb-6">Social Links</h2>
                <div className="space-y-6">
                  <div>
                    <label className="block text-sm font-medium text-slate-700">Discord Server</label>
                    <input
                      type="url"
                      value={settings.socialLinks.discord}
                      onChange={(e) => setSettings({
                        ...settings,
                        socialLinks: { ...settings.socialLinks, discord: e.target.value }
                      })}
                      className="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-[#E60012] focus:ring-[#E60012] sm:text-sm"
                    />
                  </div>
                  <div>
                    <label className="block text-sm font-medium text-slate-700">Twitter Profile</label>
                    <input
                      type="url"
                      value={settings.socialLinks.twitter}
                      onChange={(e) => setSettings({
                        ...settings,
                        socialLinks: { ...settings.socialLinks, twitter: e.target.value }
                      })}
                      className="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-[#E60012] focus:ring-[#E60012] sm:text-sm"
                    />
                  </div>
                  <div>
                    <label className="block text-sm font-medium text-slate-700">YouTube Channel</label>
                    <input
                      type="url"
                      value={settings.socialLinks.youtube}
                      onChange={(e) => setSettings({
                        ...settings,
                        socialLinks: { ...settings.socialLinks, youtube: e.target.value }
                      })}
                      className="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-[#E60012] focus:ring-[#E60012] sm:text-sm"
                    />
                  </div>
                </div>
              </div>
            )}

            {activeSection === 'categories' && (
              <div className="bg-white rounded-lg shadow p-6">
                <h2 className="text-xl font-semibold text-slate-800 mb-6">Categories</h2>
                <div className="space-y-4">
                  {settings.categories.map((category, index) => (
                    <div key={index} className="flex items-center space-x-4">
                      <input
                        type="text"
                        value={category}
                        onChange={(e) => {
                          const newCategories = [...settings.categories];
                          newCategories[index] = e.target.value;
                          setSettings({ ...settings, categories: newCategories });
                        }}
                        className="block w-full rounded-md border-gray-300 shadow-sm focus:border-[#E60012] focus:ring-[#E60012] sm:text-sm"
                      />
                      <button
                        onClick={() => {
                          const newCategories = settings.categories.filter((_, i) => i !== index);
                          setSettings({ ...settings, categories: newCategories });
                        }}
                        className="text-red-600 hover:text-red-800"
                      >
                        Remove
                      </button>
                    </div>
                  ))}
                  <button
                    onClick={() => setSettings({
                      ...settings,
                      categories: [...settings.categories, '']
                    })}
                    className="text-[#E60012] hover:text-[#CC0000]"
                  >
                    + Add Category
                  </button>
                </div>
              </div>
            )}

            {activeSection === 'payments' && (
              <div className="bg-white rounded-lg shadow p-6">
                <h2 className="text-xl font-semibold text-slate-800 mb-6">Payment Methods</h2>
                <div className="space-y-4">
                  {settings.paymentMethods.map((method, index) => (
                    <div key={index} className="flex items-center space-x-4">
                      <input
                        type="text"
                        value={method}
                        onChange={(e) => {
                          const newMethods = [...settings.paymentMethods];
                          newMethods[index] = e.target.value;
                          setSettings({ ...settings, paymentMethods: newMethods });
                        }}
                        className="block w-full rounded-md border-gray-300 shadow-sm focus:border-[#E60012] focus:ring-[#E60012] sm:text-sm"
                      />
                      <button
                        onClick={() => {
                          const newMethods = settings.paymentMethods.filter((_, i) => i !== index);
                          setSettings({ ...settings, paymentMethods: newMethods });
                        }}
                        className="text-red-600 hover:text-red-800"
                      >
                        Remove
                      </button>
                    </div>
                  ))}
                  <button
                    onClick={() => setSettings({
                      ...settings,
                      paymentMethods: [...settings.paymentMethods, '']
                    })}
                    className="text-[#E60012] hover:text-[#CC0000]"
                  >
                    + Add Payment Method
                  </button>
                </div>
              </div>
            )}
          </div>
        </div>
      </main>
    </div>
  );
} 