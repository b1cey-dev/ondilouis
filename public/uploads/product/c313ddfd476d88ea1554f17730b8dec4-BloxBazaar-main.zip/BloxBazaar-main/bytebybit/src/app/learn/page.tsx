'use client'

import { useState, useEffect } from 'react';
import Link from 'next/link';
import confetti from 'canvas-confetti';

interface Tutorial {
  id: string;
  title: string;
  description: string;
  difficulty: 'Beginner' | 'Intermediate' | 'Advanced';
  duration: string;
  topics: string[];
  content: {
    sections: {
      title: string;
      content: string;
      code?: string;
      quiz?: {
        question: string;
        options: string[];
        correctAnswer: number;
      }[];
    }[];
  };
}

interface CodeExample {
  id: string;
  title: string;
  description: string;
  code: string;
  explanation: string;
}

interface Progress {
  tutorialId: string;
  currentSection: number;
  completedSections: number[];
  quizAnswers: { [key: string]: number };
  timeSpent: number;
  completed: boolean;
}

export default function Learn() {
  const [activeTab, setActiveTab] = useState('tutorials');
  const [selectedTutorial, setSelectedTutorial] = useState<string | null>(null);
  const [selectedExample, setSelectedExample] = useState<string | null>(null);
  const [progress, setProgress] = useState<Progress | null>(null);
  const [timer, setTimer] = useState(0);
  const [showCompletion, setShowCompletion] = useState(false);
  const [error, setError] = useState<string | null>(null);

  // Timer effect
  useEffect(() => {
    let interval: NodeJS.Timeout;
    if (selectedTutorial && !progress?.completed) {
      interval = setInterval(() => {
        setTimer((prev) => prev + 1);
      }, 1000);
    }
    return () => clearInterval(interval);
  }, [selectedTutorial, progress]);

  const tutorials: Tutorial[] = [
    {
      id: 'intro-to-lua',
      title: 'Introduction to Lua',
      description: 'Learn the basics of Lua programming language used in Roblox',
      difficulty: 'Beginner',
      duration: '30 minutes',
      topics: ['Variables', 'Data Types', 'Operators', 'Functions'],
      content: {
        sections: [
          {
            title: 'What is Lua?',
            content: 'Lua is a lightweight, high-level programming language designed for embedded use in applications. In Roblox, Lua is used to create interactive experiences and games. It\'s known for its simplicity and flexibility, making it perfect for game development.',
            code: `-- This is a comment in Lua
print("Hello, Roblox!") -- Prints text to the output

-- Variables store data
local message = "Welcome to Roblox!"
print(message)`,
            quiz: [
              {
                question: 'What is Lua primarily used for in Roblox?',
                options: [
                  'Creating 3D models',
                  'Writing game scripts',
                  'Designing user interfaces',
                  'Managing player data'
                ],
                correctAnswer: 1
              }
            ]
          },
          {
            title: 'Variables and Data Types',
            content: 'Variables in Lua can store different types of data. The main data types are: numbers, strings, booleans, and tables. Understanding these is crucial for effective programming.',
            code: `-- Numbers can be integers or decimals
local age = 25
local price = 9.99

-- Strings are text
local name = "Player1"
local message = 'Hello, ' .. name

-- Booleans are true/false
local isAlive = true
local hasPowerup = false

-- Tables are like arrays or objects
local inventory = {"sword", "shield", "potion"}
local player = {
    name = "Hero",
    health = 100,
    speed = 5
}`,
            quiz: [
              {
                question: 'Which of these is NOT a valid Lua data type?',
                options: [
                  'Number',
                  'String',
                  'Boolean',
                  'Array'
                ],
                correctAnswer: 3
              }
            ]
          },
          {
            title: 'Functions',
            content: 'Functions are blocks of code that can be reused. They can take parameters and return values. Functions help organize code and make it more maintainable.',
            code: `-- Basic function
local function greet(name)
    return "Hello, " .. name .. "!"
end

-- Function with multiple parameters
local function calculateDamage(attack, defense)
    local damage = attack - defense
    if damage < 0 then
        damage = 0
    end
    return damage
end

-- Using functions
print(greet("Player")) -- Prints: Hello, Player!
local damage = calculateDamage(50, 30)
print("Damage dealt: " .. damage)`,
            quiz: [
              {
                question: 'What is the correct way to define a function in Lua?',
                options: [
                  'function myFunction()',
                  'def myFunction()',
                  'local function myFunction()',
                  'func myFunction()'
                ],
                correctAnswer: 2
              }
            ]
          }
        ]
      }
    },
    {
      id: 'basic-scripting',
      title: 'Basic Roblox Scripting',
      description: 'Start creating your first Roblox scripts',
      difficulty: 'Beginner',
      duration: '45 minutes',
      topics: ['Script Types', 'Events', 'Properties', 'Basic Game Mechanics'],
      content: {
        sections: [
          {
            title: 'Script Types in Roblox',
            content: 'Roblox has different types of scripts: LocalScripts, Scripts, and ModuleScripts. Each serves a specific purpose in game development. Understanding when to use each type is crucial.',
            code: `-- LocalScript (Client-side)
local Players = game:GetService("Players")
local player = Players.LocalPlayer

-- Script (Server-side)
local Players = game:GetService("Players")

-- ModuleScript (Reusable code)
local module = {}
function module.sayHello()
    print("Hello!")
end
return module`,
            quiz: [
              {
                question: 'Which script type runs on the client?',
                options: [
                  'Script',
                  'LocalScript',
                  'ModuleScript',
                  'All of the above'
                ],
                correctAnswer: 1
              }
            ]
          },
          {
            title: 'Events and Properties',
            content: 'Learn how to use events and properties to make your game interactive. Events are actions that happen in the game, and properties are characteristics of objects.',
            code: `-- Example of using events
local part = script.Parent
part.Touched:Connect(function(hit)
    if hit.Parent:FindFirstChild("Humanoid") then
        print("Player touched the part!")
    end
end)

-- Example of changing properties
local function changePartColor()
    part.BrickColor = BrickColor.new("Really red")
    part.Transparency = 0.5
    part.Anchored = true
end`,
            quiz: [
              {
                question: 'What event is triggered when a player touches a part?',
                options: [
                  'Click',
                  'Touched',
                  'Collided',
                  'Contact'
                ],
                correctAnswer: 1
              }
            ]
          }
        ]
      }
    },
    {
      id: 'player-interaction',
      title: 'Player Interaction',
      description: 'Learn how to handle player input and interaction',
      difficulty: 'Intermediate',
      duration: '1 hour',
      topics: ['UserInputService', 'Mouse Events', 'Touch Events', 'Key Binds'],
      content: {
        sections: [
          {
            title: 'UserInputService',
            content: 'UserInputService is a service that provides access to user input events like keyboard and mouse input. It\'s essential for creating responsive and interactive games.',
            code: `local UserInputService = game:GetService("UserInputService")

-- Handle keyboard input
UserInputService.InputBegan:Connect(function(input, gameProcessed)
    if input.KeyCode == Enum.KeyCode.Space then
        print("Space bar pressed!")
    end
end)

-- Handle mouse input
UserInputService.MouseButton1Click:Connect(function()
    print("Left mouse button clicked!")
end)`,
            quiz: [
              {
                question: 'Which service handles user input in Roblox?',
                options: [
                  'InputService',
                  'UserInputService',
                  'KeyboardService',
                  'InputManager'
                ],
                correctAnswer: 1
              }
            ]
          },
          {
            title: 'Mouse Events',
            content: 'Learn how to handle mouse input and create interactive UI elements. Mouse events are crucial for creating user interfaces and interactive elements.',
            code: `-- Create a button
local button = script.Parent
button.MouseButton1Click:Connect(function()
    print("Button clicked!")
end)

-- Handle mouse movement
button.MouseEnter:Connect(function()
    button.BackgroundColor3 = Color3.fromRGB(255, 0, 0)
end)

button.MouseLeave:Connect(function()
    button.BackgroundColor3 = Color3.fromRGB(255, 255, 255)
end)`,
            quiz: [
              {
                question: 'Which event is triggered when a button is clicked?',
                options: [
                  'MouseClick',
                  'MouseButton1Click',
                  'ButtonClick',
                  'Click'
                ],
                correctAnswer: 1
              }
            ]
          }
        ]
      }
    },
    {
      id: 'data-storage',
      title: 'Data Storage',
      description: 'Learn how to save and load player data',
      difficulty: 'Advanced',
      duration: '1.5 hours',
      topics: ['DataStore', 'JSON', 'Player Data', 'Error Handling'],
      content: {
        sections: [
          {
            title: 'DataStore Service',
            content: 'DataStore is a service that allows you to save and load data across different game sessions. It\'s essential for persistent game features like player progress and inventory.',
            code: `local DataStoreService = game:GetService("DataStoreService")
local playerData = DataStoreService:GetDataStore("PlayerData")

game.Players.PlayerAdded:Connect(function(player)
    local success, data = pcall(function()
        return playerData:GetAsync(player.UserId)
    end)
    
    if success then
        print("Data loaded successfully!")
        -- Use the loaded data
    else
        print("Error loading data:", data)
        -- Handle the error
    end
end)`,
            quiz: [
              {
                question: 'Which service is used for persistent data storage?',
                options: [
                  'StorageService',
                  'DataStore',
                  'SaveService',
                  'DataService'
                ],
                correctAnswer: 1
              }
            ]
          },
          {
            title: 'Error Handling',
            content: 'Learn how to handle errors when working with DataStore to ensure data integrity. Proper error handling is crucial for reliable data storage.',
            code: `local function saveData(player, data)
    local success, err = pcall(function()
        playerData:SetAsync(player.UserId, data)
    end)
    
    if not success then
        print("Error saving data:", err)
        -- Implement retry logic here
        wait(1) -- Wait before retrying
        saveData(player, data) -- Try again
    end
end`,
            quiz: [
              {
                question: 'What function is used to catch errors in Lua?',
                options: [
                  'try',
                  'catch',
                  'pcall',
                  'error'
                ],
                correctAnswer: 2
              }
            ]
          }
        ]
      }
    }
  ];

  const codeExamples: CodeExample[] = [
    {
      id: 'hello-world',
      title: 'Hello World',
      description: 'Basic script to print text to the output',
      code: `print("Hello, World!")`,
      explanation: 'The print() function outputs text to the Roblox Studio output window.'
    },
    {
      id: 'player-movement',
      title: 'Player Movement',
      description: 'Script to handle player movement',
      code: `local Players = game:GetService("Players")
local player = Players.LocalPlayer
local character = player.Character or player.CharacterAdded:Wait()

local function onMove(input)
    local moveDirection = Vector3.new(input.X, 0, input.Y)
    character:MoveTo(character.Position + moveDirection * 5)
end

game:GetService("UserInputService").InputBegan:Connect(function(input)
    if input.KeyCode == Enum.KeyCode.W then
        onMove(Vector3.new(0, 0, -1))
    elseif input.KeyCode == Enum.KeyCode.S then
        onMove(Vector3.new(0, 0, 1))
    elseif input.KeyCode == Enum.KeyCode.A then
        onMove(Vector3.new(-1, 0, 0))
    elseif input.KeyCode == Enum.KeyCode.D then
        onMove(Vector3.new(1, 0, 0))
    end
end)`,
      explanation: 'This script handles basic player movement using keyboard inputs. It moves the player character in the direction of the pressed key.'
    },
    {
      id: 'gui-interaction',
      title: 'GUI Interaction',
      description: 'Create an interactive button',
      code: `local Players = game:GetService("Players")
local player = Players.LocalPlayer
local playerGui = player:WaitForChild("PlayerGui")

local screenGui = Instance.new("ScreenGui")
screenGui.Parent = playerGui

local frame = Instance.new("Frame")
frame.Size = UDim2.new(0, 200, 0, 50)
frame.Position = UDim2.new(0.5, -100, 0.5, -25)
frame.BackgroundColor3 = Color3.fromRGB(255, 0, 0)
frame.Parent = screenGui

local button = Instance.new("TextButton")
button.Size = UDim2.new(1, 0, 1, 0)
button.Text = "Click Me!"
button.TextColor3 = Color3.fromRGB(255, 255, 255)
button.BackgroundTransparency = 1
button.Parent = frame

button.MouseButton1Click:Connect(function()
    print("Button clicked!")
    frame.BackgroundColor3 = Color3.fromRGB(0, 255, 0)
end)`,
      explanation: 'This script creates a simple GUI with a button that changes color when clicked.'
    }
  ];

  const formatTime = (seconds: number) => {
    const hours = Math.floor(seconds / 3600);
    const minutes = Math.floor((seconds % 3600) / 60);
    const secondsLeft = seconds % 60;
    return `${hours.toString().padStart(2, '0')}:${minutes.toString().padStart(2, '0')}:${secondsLeft.toString().padStart(2, '0')}`;
  };

  const handleStartTutorial = (tutorialId: string) => {
    const tutorial = tutorials.find(t => t.id === tutorialId);
    if (!tutorial) {
      setError('Tutorial not found');
      return;
    }

    setSelectedTutorial(tutorialId);
    setProgress({
      tutorialId,
      currentSection: 0,
      completedSections: [],
      quizAnswers: {},
      timeSpent: 0,
      completed: false
    });
    setTimer(0);
    setError(null);
  };

  const handleNextSection = () => {
    if (!progress || !selectedTutorial) return;
    
    const tutorial = tutorials.find(t => t.id === selectedTutorial);
    if (!tutorial) {
      setError('Tutorial not found');
      return;
    }

    const newProgress = { ...progress };
    newProgress.currentSection++;
    
    if (!newProgress.completedSections.includes(progress.currentSection)) {
      newProgress.completedSections.push(progress.currentSection);
    }

    if (newProgress.currentSection >= tutorial.content.sections.length) {
      newProgress.completed = true;
      setShowCompletion(true);
    }

    setProgress(newProgress);
  };

  const handleQuizAnswer = (sectionIndex: number, answerIndex: number) => {
    if (!progress) return;
    
    const newProgress = { ...progress };
    newProgress.quizAnswers[sectionIndex.toString()] = answerIndex;
    setProgress(newProgress);
  };

  const getCurrentSection = () => {
    if (!progress || !selectedTutorial) return null;
    
    const tutorial = tutorials.find(t => t.id === selectedTutorial);
    if (!tutorial) return null;

    return tutorial.content.sections[progress.currentSection];
  };

  const currentSection = getCurrentSection();

  const CompletionPage = () => {
    useEffect(() => {
      // Trigger confetti when component mounts
      confetti({
        particleCount: 100,
        spread: 70,
        origin: { y: 0.6 }
      });
    }, []);

    return (
      <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50">
        <div className="bg-white rounded-lg max-w-2xl w-full p-8 transform transition-all">
          <div className="text-center">
            <h2 className="text-3xl font-bold text-slate-800 mb-4">Congratulations! 🎉</h2>
            <p className="text-slate-600 mb-6">You've completed the tutorial!</p>
            
            <div className="grid grid-cols-2 gap-4 mb-8">
              <div className="bg-slate-50 p-4 rounded-lg">
                <p className="text-sm text-slate-500">Time Spent</p>
                <p className="text-xl font-semibold text-slate-800">{formatTime(timer)}</p>
              </div>
              <div className="bg-slate-50 p-4 rounded-lg">
                <p className="text-sm text-slate-500">Sections Completed</p>
                <p className="text-xl font-semibold text-slate-800">
                  {progress?.completedSections.length}/{tutorials.find(t => t.id === progress?.tutorialId)?.content.sections.length}
                </p>
              </div>
            </div>

            <div className="space-y-4">
              <button
                onClick={() => {
                  setShowCompletion(false);
                  setSelectedTutorial(null);
                  setProgress(null);
                }}
                className="w-full bg-[#E60012] text-white px-6 py-3 rounded-lg font-medium hover:bg-[#CC0000] transition"
              >
                Back to Tutorials
              </button>
              <button
                onClick={() => {
                  setShowCompletion(false);
                  setProgress({
                    ...progress!,
                    currentSection: 0,
                    completedSections: [],
                    quizAnswers: {},
                    completed: false
                  });
                }}
                className="w-full bg-slate-100 text-slate-800 px-6 py-3 rounded-lg font-medium hover:bg-slate-200 transition"
              >
                Restart Tutorial
              </button>
            </div>
          </div>
        </div>
      </div>
    );
  };

  return (
    <div className="min-h-screen bg-gray-100">
      {/* Navbar */}
      <nav className="bg-white border-b border-gray-200 sticky top-0 shadow-sm">
        <div className="max-w-7xl mx-auto px-4 h-14 flex items-center justify-between">
          <div className="flex items-center">
            <Link href="/" className="text-slate-800 font-bold text-xl flex items-center">
              <span className="text-[#E60012]">Blox</span>
              <span>Bazaar</span>
            </Link>
          </div>
          
          <div className="hidden md:flex items-center space-x-1">
            <Link href="/marketplace" className="px-3 py-2 text-slate-600 rounded hover:bg-slate-50 flex items-center">
              <svg xmlns="http://www.w3.org/2000/svg" className="h-5 w-5 mr-1" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2">
                <path d="M3 3h18v18H3zM12 8v8m-4-4h8"></path>
              </svg>
              <span>Marketplace</span>
            </Link>

            <Link href="/forums" className="px-3 py-2 text-slate-600 rounded hover:bg-slate-50 flex items-center">
              <svg xmlns="http://www.w3.org/2000/svg" className="h-5 w-5 mr-1" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2">
                <path d="M21 15a2 2 0 0 1-2 2H7l-4 4V5a2 2 0 0 1 2-2h14a2 2 0 0 1 2 2z"></path>
              </svg>
              <span>Forums</span>
            </Link>
            
            <Link href="/learn" className="px-3 py-2 text-slate-600 rounded hover:bg-slate-50 flex items-center">
              <svg xmlns="http://www.w3.org/2000/svg" className="h-5 w-5 mr-1" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2">
                <path d="M2 3h6a4 4 0 0 1 4 4v14a3 3 0 0 0-3-3H2z"></path>
                <path d="M22 3h-6a4 4 0 0 0-4 4v14a3 3 0 0 1 3-3h7z"></path>
              </svg>
              <span>Learn</span>
            </Link>
          </div>
          
          <div className="flex items-center space-x-3">
            <Link href="/go-pro" className="bg-[#E60012] text-white px-4 sm:px-6 py-2 rounded text-sm font-medium flex items-center hover:bg-[#CC0000] transition">
              <svg xmlns="http://www.w3.org/2000/svg" className="h-5 w-5 mr-1" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2">
                <path d="M12 2L2 7l10 5 10-5-10-5zM2 17l10 5 10-5M2 12l10 5 10-5"></path>
              </svg>
              <span>Go Pro</span>
            </Link>
            
            <div className="flex items-center space-x-2">
              <Link href="/account" className="w-8 h-8 rounded-full bg-slate-800 text-white flex items-center justify-center font-bold hover:bg-slate-700 transition">
                A
              </Link>
            </div>
          </div>
        </div>
      </nav>

      {/* Header */}
      <div className="bg-gradient-to-r from-slate-800 to-slate-900 py-12">
        <div className="max-w-7xl mx-auto px-4">
          <div className="text-white">
            <h1 className="text-3xl font-bold">Learn Roblox Scripting</h1>
            <p className="text-slate-300 mt-2">Master the art of Roblox development with our comprehensive tutorials and examples</p>
          </div>
        </div>
      </div>

      {/* Main Content */}
      <main className="max-w-7xl mx-auto px-4 py-8">
        {error && (
          <div className="bg-red-50 border border-red-200 text-red-700 px-4 py-3 rounded mb-4">
            {error}
          </div>
        )}

        {!selectedTutorial ? (
          <>
            {/* Tabs */}
            <div className="flex space-x-4 mb-8">
              <button
                onClick={() => setActiveTab('tutorials')}
                className={`px-4 py-2 rounded-lg font-medium ${
                  activeTab === 'tutorials'
                    ? 'bg-[#E60012] text-white'
                    : 'bg-white text-slate-600 hover:bg-slate-50'
                }`}
              >
                Tutorials
              </button>
              <button
                onClick={() => setActiveTab('examples')}
                className={`px-4 py-2 rounded-lg font-medium ${
                  activeTab === 'examples'
                    ? 'bg-[#E60012] text-white'
                    : 'bg-white text-slate-600 hover:bg-slate-50'
                }`}
              >
                Code Examples
              </button>
            </div>

            {/* Content */}
            {activeTab === 'tutorials' && (
              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
                {tutorials.map((tutorial) => (
                  <div
                    key={tutorial.id}
                    className="bg-white rounded-lg shadow overflow-hidden hover:shadow-md transition"
                  >
                    <div className="p-6">
                      <div className="flex items-center justify-between mb-4">
                        <span className={`px-2 py-1 rounded text-xs font-medium ${
                          tutorial.difficulty === 'Beginner'
                            ? 'bg-green-100 text-green-800'
                            : tutorial.difficulty === 'Intermediate'
                            ? 'bg-yellow-100 text-yellow-800'
                            : 'bg-red-100 text-red-800'
                        }`}>
                          {tutorial.difficulty}
                        </span>
                        <span className="text-sm text-slate-500">{tutorial.duration}</span>
                      </div>
                      <h3 className="text-xl font-semibold text-slate-800 mb-2">{tutorial.title}</h3>
                      <p className="text-slate-600 mb-4">{tutorial.description}</p>
                      <div className="flex flex-wrap gap-2">
                        {tutorial.topics.map((topic, index) => (
                          <span
                            key={index}
                            className="px-2 py-1 bg-slate-100 text-slate-600 rounded text-xs"
                          >
                            {topic}
                          </span>
                        ))}
                      </div>
                    </div>
                    <div className="bg-slate-50 px-6 py-4">
                      <button
                        onClick={() => handleStartTutorial(tutorial.id)}
                        className="w-full bg-[#E60012] text-white px-4 py-2 rounded-lg font-medium hover:bg-[#CC0000] transition"
                      >
                        Start Learning
                      </button>
                    </div>
                  </div>
                ))}
              </div>
            )}

            {activeTab === 'examples' && (
              <div className="grid grid-cols-1 gap-6">
                {codeExamples.map((example) => (
                  <div
                    key={example.id}
                    className="bg-white rounded-lg shadow overflow-hidden"
                  >
                    <div className="p-6">
                      <h3 className="text-xl font-semibold text-slate-800 mb-2">{example.title}</h3>
                      <p className="text-slate-600 mb-4">{example.description}</p>
                      <div className="bg-slate-800 rounded-lg p-4 mb-4">
                        <pre className="text-slate-200 overflow-x-auto">
                          <code>{example.code}</code>
                        </pre>
                      </div>
                      <div className="bg-slate-50 p-4 rounded-lg">
                        <h4 className="font-medium text-slate-800 mb-2">Explanation:</h4>
                        <p className="text-slate-600">{example.explanation}</p>
                      </div>
                    </div>
                  </div>
                ))}
              </div>
            )}
          </>
        ) : (
          <div className="bg-white rounded-lg shadow overflow-hidden">
            <div className="p-6">
              <div className="flex justify-between items-center mb-6">
                <div>
                  <h2 className="text-2xl font-bold text-slate-800">
                    {tutorials.find(t => t.id === selectedTutorial)?.title}
                  </h2>
                  <p className="text-slate-500">Time: {formatTime(timer)}</p>
                </div>
                <div className="flex items-center space-x-4">
                  <div className="bg-slate-100 px-4 py-2 rounded-lg">
                    <span className="text-slate-600">
                      Section {progress?.currentSection! + 1} of {tutorials.find(t => t.id === selectedTutorial)?.content.sections.length}
                    </span>
                  </div>
                  <button
                    onClick={() => {
                      setSelectedTutorial(null);
                      setProgress(null);
                    }}
                    className="text-slate-500 hover:text-slate-700"
                  >
                    <svg xmlns="http://www.w3.org/2000/svg" className="h-6 w-6" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                      <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M6 18L18 6M6 6l12 12" />
                    </svg>
                  </button>
                </div>
              </div>

              {progress && currentSection && (
                <div className="space-y-6">
                  <div className="prose max-w-none">
                    <h3 className="text-xl font-semibold text-slate-800 mb-4">
                      {currentSection.title}
                    </h3>
                    <p className="text-slate-600 mb-4">
                      {currentSection.content}
                    </p>
                    
                    {currentSection.code && (
                      <div className="bg-slate-800 rounded-lg p-4 mb-4">
                        <pre className="text-slate-200 overflow-x-auto">
                          <code>
                            {currentSection.code}
                          </code>
                        </pre>
                      </div>
                    )}

                    {currentSection.quiz && (
                      <div className="bg-slate-50 p-4 rounded-lg">
                        <h4 className="font-medium text-slate-800 mb-4">Quiz</h4>
                        {currentSection.quiz.map((question, index) => (
                          <div key={index} className="mb-4">
                            <p className="text-slate-700 mb-2">{question.question}</p>
                            <div className="space-y-2">
                              {question.options.map((option, optionIndex) => (
                                <button
                                  key={optionIndex}
                                  onClick={() => handleQuizAnswer(progress.currentSection, optionIndex)}
                                  className={`w-full text-left px-4 py-2 rounded-lg ${
                                    progress.quizAnswers[progress.currentSection.toString()] === optionIndex
                                      ? 'bg-[#E60012] text-white'
                                      : 'bg-white text-slate-600 hover:bg-slate-50'
                                  }`}
                                >
                                  {option}
                                </button>
                              ))}
                            </div>
                          </div>
                        ))}
                      </div>
                    )}
                  </div>

                  <div className="flex justify-end">
                    <button
                      onClick={handleNextSection}
                      className="bg-[#E60012] text-white px-6 py-2 rounded-lg font-medium hover:bg-[#CC0000] transition"
                    >
                      {progress.currentSection === tutorials.find(t => t.id === selectedTutorial)?.content.sections.length! - 1
                        ? 'Complete Tutorial'
                        : 'Next Section'}
                    </button>
                  </div>
                </div>
              )}
            </div>
          </div>
        )}

        {showCompletion && <CompletionPage />}
      </main>
    </div>
  );
} 