'use client'

import { useState } from 'react';
import Link from 'next/link';
import Image from 'next/image';

interface Feature {
  name: string;
  description: string;
  icon: string;
}

interface Tier {
  name: string;
  price: string;
  features: string[];
  popular?: boolean;
}

export default function GoPro() {
  const [selectedTier, setSelectedTier] = useState('pro');

  const features: Feature[] = [
    {
      name: 'Priority Support',
      description: 'Get your questions answered faster with dedicated support',
      icon: 'M18.364 5.636l-3.536 3.536m0 5.656l3.536 3.536M9.172 9.172L5.636 5.636m3.536 9.192l-3.536 3.536M21 12a9 9 0 11-18 0 9 9 0 0118 0zm-5 0a4 4 0 11-8 0 4 4 0 018 0z'
    },
    {
      name: 'Advanced Analytics',
      description: 'Track your product performance with detailed insights',
      icon: 'M9 19v-6a2 2 0 00-2-2H5a2 2 0 00-2 2v6a2 2 0 002 2h2a2 2 0 002-2zm0 0V9a2 2 0 012-2h2a2 2 0 012 2v10m-6 0a2 2 0 002 2h2a2 2 0 002-2m0 0V5a2 2 0 012-2h2a2 2 0 012 2v14a2 2 0 01-2 2h-2a2 2 0 01-2-2z'
    },
    {
      name: 'Custom Branding',
      description: 'Showcase your brand with custom storefront options',
      icon: 'M4 5a1 1 0 011-1h14a1 1 0 011 1v2a1 1 0 01-1 1H5a1 1 0 01-1-1V5zM4 13a1 1 0 011-1h6a1 1 0 011 1v6a1 1 0 01-1 1H5a1 1 0 01-1-1v-6zM16 13a1 1 0 011-1h2a1 1 0 011 1v6a1 1 0 01-1 1h-2a1 1 0 01-1-1v-6z'
    },
    {
      name: 'Early Access',
      description: 'Be the first to try new features and updates',
      icon: 'M12 8v4l3 3m6-3a9 9 0 11-18 0 9 9 0 0118 0z'
    }
  ];

  const tiers: Tier[] = [
    {
      name: 'Basic',
      price: 'Free',
      features: [
        'Basic product listings',
        'Standard support',
        'Basic analytics',
        'Community access'
      ]
    },
    {
      name: 'Pro',
      price: '$9.99',
      popular: true,
      features: [
        'Everything in Basic',
        'Priority support',
        'Advanced analytics',
        'Custom branding',
        'Early access to features',
        'Higher commission rates'
      ]
    },
    {
      name: 'Enterprise',
      price: 'Custom',
      features: [
        'Everything in Pro',
        'Dedicated account manager',
        'Custom integrations',
        'API access',
        'White-label solutions',
        'Volume discounts'
      ]
    }
  ];

  return (
    <div className="min-h-screen bg-gray-100">
      {/* Navbar */}
      <nav className="bg-white border-b border-gray-200 sticky top-0 shadow-sm">
        <div className="max-w-7xl mx-auto px-4 h-14 flex items-center justify-between">
          <div className="flex items-center">
            <Link href="/" className="text-slate-800 font-bold text-xl flex items-center">
              <span className="text-[#E60012]">Blox</span>
              <span>Bazaar</span>
            </Link>
          </div>
          
          <div className="hidden md:flex items-center space-x-1">
            <Link href="/marketplace" className="px-3 py-2 text-slate-600 rounded hover:bg-slate-50 flex items-center">
              <svg xmlns="http://www.w3.org/2000/svg" className="h-5 w-5 mr-1" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2">
                <path d="M3 3h18v18H3zM12 8v8m-4-4h8"></path>
              </svg>
              <span>Marketplace</span>
            </Link>

            <Link href="/forums" className="px-3 py-2 text-slate-600 rounded hover:bg-slate-50 flex items-center">
              <svg xmlns="http://www.w3.org/2000/svg" className="h-5 w-5 mr-1" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2">
                <path d="M21 15a2 2 0 0 1-2 2H7l-4 4V5a2 2 0 0 1 2-2h14a2 2 0 0 1 2 2z"></path>
              </svg>
              <span>Forums</span>
            </Link>
            
            <Link href="/learn" className="px-3 py-2 text-slate-600 rounded hover:bg-slate-50 flex items-center">
              <svg xmlns="http://www.w3.org/2000/svg" className="h-5 w-5 mr-1" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2">
                <path d="M2 3h6a4 4 0 0 1 4 4v14a3 3 0 0 0-3-3H2z"></path>
                <path d="M22 3h-6a4 4 0 0 0-4 4v14a3 3 0 0 1 3-3h7z"></path>
              </svg>
              <span>Learn</span>
            </Link>
          </div>
          
          <div className="flex items-center space-x-3">
            <Link href="/go-pro" className="bg-[#E60012] text-white px-4 sm:px-6 py-2 rounded text-sm font-medium flex items-center hover:bg-[#CC0000] transition">
              <svg xmlns="http://www.w3.org/2000/svg" className="h-5 w-5 mr-1" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2">
                <path d="M12 2L2 7l10 5 10-5-10-5zM2 17l10 5 10-5M2 12l10 5 10-5"></path>
              </svg>
              <span>Go Pro</span>
            </Link>
            
            <div className="flex items-center space-x-2">
              <Link href="/account" className="w-8 h-8 rounded-full bg-slate-800 text-white flex items-center justify-center font-bold hover:bg-slate-700 transition">
                A
              </Link>
            </div>
          </div>
        </div>
      </nav>

      {/* Hero Section */}
      <div className="bg-gradient-to-r from-slate-800 to-slate-900 py-16">
        <div className="max-w-7xl mx-auto px-4 text-center">
          <h1 className="text-4xl md:text-5xl font-bold text-white mb-6">
            Take Your Roblox Development to the Next Level
          </h1>
          <p className="text-xl text-slate-300 mb-8 max-w-3xl mx-auto">
            Unlock powerful features to grow your Roblox development business and reach more customers.
          </p>
          <div className="flex justify-center space-x-4">
            <Link
              href="#pricing"
              className="bg-[#E60012] text-white px-6 py-3 rounded-lg font-medium hover:bg-[#CC0000] transition"
            >
              View Plans
            </Link>
            <Link
              href="#features"
              className="bg-white text-slate-800 px-6 py-3 rounded-lg font-medium hover:bg-slate-100 transition"
            >
              Learn More
            </Link>
          </div>
        </div>
      </div>

      {/* Features Section */}
      <div id="features" className="py-16 bg-white">
        <div className="max-w-7xl mx-auto px-4">
          <h2 className="text-3xl font-bold text-slate-800 text-center mb-12">
            Pro Features
          </h2>
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8">
            {features.map((feature) => (
              <div key={feature.name} className="bg-slate-50 rounded-lg p-6">
                <div className="w-12 h-12 bg-[#E60012] rounded-lg flex items-center justify-center mb-4">
                  <svg
                    className="w-6 h-6 text-white"
                    fill="none"
                    stroke="currentColor"
                    viewBox="0 0 24 24"
                    xmlns="http://www.w3.org/2000/svg"
                  >
                    <path
                      strokeLinecap="round"
                      strokeLinejoin="round"
                      strokeWidth={2}
                      d={feature.icon}
                    />
                  </svg>
                </div>
                <h3 className="text-xl font-semibold text-slate-800 mb-2">
                  {feature.name}
                </h3>
                <p className="text-slate-600">{feature.description}</p>
              </div>
            ))}
          </div>
        </div>
      </div>

      {/* Pricing Section */}
      <div id="pricing" className="py-16 bg-gray-100">
        <div className="max-w-7xl mx-auto px-4">
          <h2 className="text-3xl font-bold text-slate-800 text-center mb-12">
            Choose Your Plan
          </h2>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
            {tiers.map((tier) => (
              <div
                key={tier.name}
                className={`bg-white rounded-lg shadow-lg overflow-hidden ${
                  tier.popular ? 'border-2 border-[#E60012]' : ''
                }`}
              >
                {tier.popular && (
                  <div className="bg-[#E60012] text-white text-center py-1 text-sm font-medium">
                    Most Popular
                  </div>
                )}
                <div className="p-6">
                  <h3 className="text-2xl font-bold text-slate-800 mb-2">
                    {tier.name}
                  </h3>
                  <div className="text-4xl font-bold text-slate-800 mb-4">
                    {tier.price}
                    {tier.price !== 'Free' && (
                      <span className="text-lg text-slate-600">/month</span>
                    )}
                  </div>
                  <ul className="space-y-3 mb-6">
                    {tier.features.map((feature) => (
                      <li key={feature} className="flex items-center">
                        <svg
                          className="w-5 h-5 text-[#E60012] mr-2"
                          fill="none"
                          stroke="currentColor"
                          viewBox="0 0 24 24"
                          xmlns="http://www.w3.org/2000/svg"
                        >
                          <path
                            strokeLinecap="round"
                            strokeLinejoin="round"
                            strokeWidth={2}
                            d="M5 13l4 4L19 7"
                          />
                        </svg>
                        <span className="text-slate-600">{feature}</span>
                      </li>
                    ))}
                  </ul>
                  <button
                    className={`w-full py-3 rounded-lg font-medium transition ${
                      tier.popular
                        ? 'bg-[#E60012] text-white hover:bg-[#CC0000]'
                        : 'bg-slate-100 text-slate-800 hover:bg-slate-200'
                    }`}
                    onClick={() => setSelectedTier(tier.name.toLowerCase())}
                  >
                    {tier.name === 'Basic' ? 'Get Started' : 'Choose Plan'}
                  </button>
                </div>
              </div>
            ))}
          </div>
        </div>
      </div>

      {/* FAQ Section */}
      <div className="py-16 bg-white">
        <div className="max-w-7xl mx-auto px-4">
          <h2 className="text-3xl font-bold text-slate-800 text-center mb-12">
            Frequently Asked Questions
          </h2>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
            <div className="bg-slate-50 rounded-lg p-6">
              <h3 className="text-xl font-semibold text-slate-800 mb-2">
                What payment methods do you accept?
              </h3>
              <p className="text-slate-600">
                We accept all major credit cards, PayPal, and Robux payments for your convenience.
              </p>
            </div>
            <div className="bg-slate-50 rounded-lg p-6">
              <h3 className="text-xl font-semibold text-slate-800 mb-2">
                Can I upgrade or downgrade my plan?
              </h3>
              <p className="text-slate-600">
                Yes, you can change your plan at any time. Changes will be reflected in your next billing cycle.
              </p>
            </div>
            <div className="bg-slate-50 rounded-lg p-6">
              <h3 className="text-xl font-semibold text-slate-800 mb-2">
                Is there a free trial?
              </h3>
              <p className="text-slate-600">
                Yes, we offer a 14-day free trial for our Pro plan. No credit card required.
              </p>
            </div>
            <div className="bg-slate-50 rounded-lg p-6">
              <h3 className="text-xl font-semibold text-slate-800 mb-2">
                What happens if I cancel?
              </h3>
              <p className="text-slate-600">
                You'll continue to have access to Pro features until the end of your billing period.
              </p>
            </div>
          </div>
        </div>
      </div>

      {/* CTA Section */}
      <div className="bg-gradient-to-r from-slate-800 to-slate-900 py-16">
        <div className="max-w-7xl mx-auto px-4 text-center">
          <h2 className="text-3xl font-bold text-white mb-6">
            Ready to Grow Your Roblox Business?
          </h2>
          <p className="text-xl text-slate-300 mb-8 max-w-3xl mx-auto">
            Join thousands of successful Roblox developers who trust BloxBazaar Pro.
          </p>
          <Link
            href="#pricing"
            className="bg-[#E60012] text-white px-8 py-4 rounded-lg font-medium hover:bg-[#CC0000] transition text-lg"
          >
            Get Started Today
          </Link>
        </div>
      </div>
    </div>
  );
} 